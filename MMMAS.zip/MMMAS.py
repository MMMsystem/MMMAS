#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
孟德尔错配矩阵分析系统 / Mendelian Mismatch Matrix Analysis System
Mendelian Mismatch Matrix Analysis System - v1.0

功能 / Function:
  从原始基因型数据自动识别格式、构建 MMM 矩阵
  Automatically detect format from raw genotype data and build MMM matrix
  构建完成后自动输出全部分级分析文件
  Automatically output all grading analysis files after build

作者 / Author: 陈启亮 陈刘秀等
版本 / Version: 1.0.0
日期 / Date: 2026-07-19
"""

import sys
import os
import re
import time
import platform
import argparse
import queue
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from contextlib import contextmanager
from datetime import datetime
from typing import Dict, List, Tuple, Optional, Callable, TYPE_CHECKING
from dataclasses import dataclass, field
from concurrent.futures import ThreadPoolExecutor, as_completed
import multiprocessing

try:
    import psutil
except ImportError:  # pragma: no cover
    psutil = None

if TYPE_CHECKING:
    import psutil

import numpy as np
import pandas as pd

# 版本信息
__version__ = "1.0.0"
__author__ = "MMM Assistant"

# ========================================================================
# 国际化支持 / Internationalization Support
# ========================================================================

class I18n:
    """
    国际化文本管理器 / Internationalization Text Manager
    支持中英文切换 / Supports Chinese-English switching
    """
    _lang = 'zh'  # 默认语言 default language

    # 翻译字典 / Translation dictionary
    _dict = {
        # === GUI Text ===
        'app_title': {'zh': '孟德尔错配矩阵分析系统 - v1.0', 'en': 'Mendelian Mismatch Matrix Analysis System - v1.0'},
        'app_subtitle': {'zh': 'Mendelian Mismatch Matrix Analysis System - v1.0', 'en': 'Mendelian Mismatch Matrix Analysis System - v1.0'},
        'tab_builder': {'zh': '  矩阵构建  ', 'en': '  Matrix Build  '},
        'status_ready': {'zh': '就绪', 'en': 'Ready'},
        'status_building': {'zh': '正在构建矩阵，请稍候...', 'en': 'Building matrix, please wait...'},
        'label_input': {'zh': '输入CSV文件:', 'en': 'Input CSV File:'},
        'label_output': {'zh': '输出目录:', 'en': 'Output Directory:'},
        'label_marker': {'zh': '标记类型:', 'en': 'Marker Type:'},
        'btn_browse': {'zh': '浏览...', 'en': 'Browse...'},
        'frame_options': {'zh': '高级选项', 'en': 'Advanced Options'},
        'chk_threads': {'zh': '启用多线程', 'en': 'Enable Multithreading'},
        'btn_run': {'zh': '▶ 开始分析', 'en': '▶ Start Analysis'},
        'frame_help': {'zh': '使用说明', 'en': 'Usage Instructions'},
        'frame_log': {'zh': '分析日志', 'en': 'Analysis Log'},
        'lang_label': {'zh': '语言 / Language:', 'en': '语言 / Language:'},
        'help_text': {
            'zh': '1. 选择原始基因型CSV文件 → 2. 选择输出目录 → 3. 点击【开始分析】\n支持格式: 格式A(等位基因分离) / 格式B(斜杠分隔) / 格式C(SSR原始双表头) / 格式D(SNP转置) / SNP(0/1/2编码)',
            'en': '1. Select raw genotype CSV → 2. Select output directory → 3. Click [Start Analysis]\nSupported: Format A (allele split) / Format B (slash) / Format C (SSR double header) / Format D (SNP transposed) / SNP (0/1/2)'
        },
        'dialog_select_input': {'zh': '选择输入CSV文件', 'en': 'Select Input CSV File'},
        'dialog_select_output': {'zh': '选择输出目录', 'en': 'Select Output Directory'},
        'filetype_csv': {'zh': 'CSV文件', 'en': 'CSV Files'},
        'filetype_all': {'zh': '所有文件', 'en': 'All Files'},
        'err_no_input': {'zh': '请选择有效的输入CSV文件', 'en': 'Please select a valid input CSV file'},
        'err_no_output': {'zh': '请选择输出目录', 'en': 'Please select an output directory'},
        'msg_success': {'zh': '矩阵构建成功完成！', 'en': 'Matrix build completed successfully!'},
        'auto_detect': {'zh': '自动检测', 'en': 'Auto Detect'},

        # === Phase Names ===
        'phase1': {'zh': '【Phase 1】数据加载与格式识别...', 'en': '[Phase 1] Data Loading & Format Detection...'},
        'phase2': {'zh': '【Phase 2】构建基因型数组...', 'en': '[Phase 2] Building Genotype Array...'},
        'phase3': {'zh': '【Phase 3】计算孟德尔错配矩阵...', 'en': '[Phase 3] Calculating Mismatch Matrix...'},
        'phase4': {'zh': '【Phase 4】执行矩阵验证...', 'en': '[Phase 4] Performing Matrix Validation...'},
        'phase5': {'zh': '【Phase 5】计算Dk分级...', 'en': '[Phase 5] Calculating Dk Classification...'},
        'phase5b': {'zh': '【Phase 5b】检测零错配对及Mmmd...', 'en': '[Phase 5b] Detecting Zero-Mismatch Pairs & Mmmd...'},
        'phase6': {'zh': '【Phase 6】执行分级分析...', 'en': '[Phase 6] Performing Grading Analysis...'},
        'phase7': {'zh': '【Phase 7】生成报告...', 'en': '[Phase 7] Generating Report...'},

        # === Common Output ===
        'time_cost': {'zh': '⏱ 耗时', 'en': '⏱ Time'},
        'seconds': {'zh': '秒', 'en': 's'},
        'done': {'zh': '完成', 'en': 'Done'},
        'pass': {'zh': '通过', 'en': 'Pass'},
        'fail': {'zh': '失败', 'en': 'Fail'},
        'error': {'zh': '错误', 'en': 'Error'},
        'all_passed': {'zh': '全部通过', 'en': 'All Passed'},
        'partial_failed': {'zh': '部分未通过', 'en': 'Partially Failed'},

        # === Data Loading ===
        'fmt_detected': {'zh': '数据格式', 'en': 'Data Format'},
        'fmt_original': {'zh': '格式B（单栏基因型格式）', 'en': 'Format B (single-column genotype)'},
        'fmt_reformatted': {'zh': '格式A（单栏等位基因分离格式）', 'en': 'Format A (allele split)'},
        'fmt_snp': {'zh': 'SNP（0/1/2编码）', 'en': 'SNP (0/1/2 encoding)'},
        'fmt_transposed_snp': {'zh': '格式D（SNP转置格式）', 'en': 'Format D (SNP transposed)'},
        'fmt_format_c': {'zh': '格式C（SSR原始双表头格式）', 'en': 'Format C (SSR double header)'},
        'sample_count': {'zh': '样本数', 'en': 'Samples'},
        'locus_count': {'zh': '位点数', 'en': 'Loci'},
        'marker_type_user': {'zh': '标记类型(用户指定)', 'en': 'Marker Type (User)'},
        'marker_type_auto': {'zh': '标记类型(自动检测)', 'en': 'Marker Type (Auto)'},
        'genotype_matrix': {'zh': '基因型矩阵', 'en': 'Genotype Matrix'},
        'pairs_calculated': {'zh': '完成组合计算', 'en': 'Pairs Calculated'},
        'mmap_mode_notice': {'zh': '检测到大规模数据集，启用内存映射模式（矩阵将暂存磁盘）', 'en': 'Large dataset detected; enabling memory-mapped mode (matrix will be cached on disk)'},
        'mmap_skip_matrix_csv': {'zh': '内存映射模式：跳过完整 N×N 矩阵 CSV 输出（文件过大）', 'en': 'Memory-mapped mode: skipping full N×N matrix CSV output (file too large)'},

        # === Validation ===
        'validation_symmetry': {'zh': '对称性验证', 'en': 'Symmetry Validation'},
        'validation_nonnegative': {'zh': '非负性验证', 'en': 'Non-Negativity'},
        'validation_bounded': {'zh': '有界性验证', 'en': 'Boundedness'},
        'validation_integer': {'zh': '整数性验证', 'en': 'Integrality'},
        'validation_diagonal': {'zh': '对角线规则验证', 'en': 'Diagonal Rule'},
        'final_conclusion': {'zh': '最终结论', 'en': 'Final Conclusion'},

        # === Dk & Grading ===
        'mmin_range': {'zh': 'Mmin范围', 'en': 'Mmin Range'},
        'gap_index': {'zh': '间隙指数', 'en': 'Gap Index'},
        'zero_pairs': {'zh': '零错配对', 'en': 'Zero-Mismatch Pairs'},
        'dup_pairs': {'zh': '完全重复(Mmmd=1)', 'en': 'Complete Duplicates (Mmmd=1)'},
        'grading_system': {'zh': '分级体系', 'en': 'Grading System'},
        'grading_levels': {'zh': '级', 'en': 'Levels'},
        'dup_groups': {'zh': '重复样本组', 'en': 'Duplicate Groups'},

        # === File Output Labels ===
        'file_m_matrix': {'zh': '错配矩阵', 'en': 'Mismatch Matrix'},
        'file_l_matrix': {'zh': '有效位点矩阵', 'en': 'Effective Loci Matrix'},
        'file_rate_matrix': {'zh': '孟德尔错配率矩阵', 'en': 'Mendelian Mismatch Rate Matrix'},
        'file_mnp': {'zh': '低错配品种对(M≤2)', 'en': 'Low-Mismatch Pairs (M≤2)'},
        'file_zero_pairs': {'zh': '零错配对', 'en': 'Zero-Mismatch Pairs'},
        'file_basic': {'zh': '基础指标表', 'en': 'Basic Metrics'},
        'file_grading_summary': {'zh': '分级汇总表', 'en': 'Grading Summary'},
        'dk_grade': {'zh': 'Dk级别', 'en': 'Dk Grade'},
        'file_frequency': {'zh': '频率分布', 'en': 'Frequency Distribution'},
        'file_mgi': {'zh': '孟德尔等级间隙指数', 'en': 'Mendelian Grade Gap Index'},
        'file_dup_pairs': {'zh': '重复样本对', 'en': 'Duplicate Pairs'},
        'file_dup_groups': {'zh': '重复样本组', 'en': 'Duplicate Groups'},
        'file_report': {'zh': '分析报告', 'en': 'Analysis Report'},
        'file_summary': {'zh': '构建报告', 'en': 'Build Report'},
        'file_only_data': {'zh': '去重后数据', 'en': 'Deduplicated Data'},

        # === File Descriptions ===
        'desc_m_matrix': {'zh': 'N×N对称矩阵，记录样本i与j的孟德尔不兼容位点数，对角线为NA', 'en': 'N×N symmetric matrix recording Mendelian incompatible loci between sample i and j; diagonal is NA'},
        'desc_l_matrix': {'zh': 'N×N矩阵，记录样本i与j可有效比较的位点数', 'en': 'N×N matrix recording effective comparable loci between sample i and j'},
        'desc_rate_matrix': {'zh': 'N×N矩阵，记录样本i与j的孟德尔错配率（Mmn/L）', 'en': 'N×N matrix recording Mendelian mismatch rate between sample i and j (Mmn/L)'},
        'desc_mnp': {'zh': '错配数在0~2之间的品种对列表，共 {} 对，可用于亲缘关系分析', 'en': 'List of pairs with mismatch count 0~2, total {} pairs; useful for kinship analysis'},
        'desc_zero_pairs': {'zh': 'Mzmp=0的样本对及是否完全重复(Mmmd=1)，Mmmd=1表示重复样本', 'en': 'Pairs with Mzmp=0 and duplicate status (Mmmd=1); Mmmd=1 means duplicate samples'},
        'desc_basic': {'zh': '每个样本的核心指标：Mmin、Dk级别、Mmax、Mavg、Mzmp、Mzmp list.', 'en': 'Core metrics per sample: Mmin, Dk Grade, Mmax, Mavg, Mzmp, Mzmp list.'},
        'desc_grading_summary': {'zh': '各等级Dk(差级)/Ck(累级)的样本数、占比及成员列表', 'en': 'Sample count, percentage and member list for each Dk/Ck grade'},
        'desc_mgi': {'zh': 'MGI=空Dk等级数/总等级数，MGI=0表示分级连续无空档，MGI>0表示存在间断', 'en': 'MGI=empty Dk grades/total grades; MGI=0 = continuous, MGI>0 = gaps exist'},
        'desc_dup_pairs': {'zh': 'Mmmd=1的完全重复样本对，两样本在所有位点上基因型完全一致', 'en': 'Complete duplicate pairs (Mmmd=1); identical genotypes at all loci'},
        'desc_dup_groups': {'zh': '使用并查集合并的重复样本组，组内样本两两之间均为Mmmd=1', 'en': 'Duplicate groups merged by Union-Find; all intra-group pairs are Mmmd=1'},
        'desc_report': {'zh': '包含运行参数、验证结果、分级概要的表格报告', 'en': 'Table report with run parameters, validation results and grading summary'},
        'desc_summary': {'zh': '包含运行时间、各阶段耗时、输出文件列表、文件说明的文本报告', 'en': 'Text report with runtime, phase timings, output file list and descriptions'},
        'desc_only_data': {'zh': '自动去除重复样本（每组仅保留第一个）后的基因型数据，可直接用于后续分析', 'en': 'Genotype data after removing duplicates (retaining first per group); ready for downstream analysis'},
        'hint_only_data': {'zh': '★ 重要提示: 该文件可直接作为输入进行下一步矩阵构建，构建结果将不包含重复样本', 'en': '★ Important: This file can be directly used for next matrix build; duplicates excluded'},

        # === Statistics ===
        'original_count': {'zh': '原始样本数', 'en': 'Original Samples'},
        'dedup_count': {'zh': '去重后样本数', 'en': 'Deduplicated Samples'},
        'removed_count': {'zh': '删除样本数', 'en': 'Removed Samples'},
        'removed_ids': {'zh': '删除样本ID', 'en': 'Removed IDs'},
        'usage': {'zh': '用途', 'en': 'Usage'},
        'direct_input': {'zh': '可直接作为输入重新进行矩阵构建', 'en': 'Can be directly used as input for matrix rebuild'},
        'no_dup_detected': {'zh': '未检测到完全重复样本(Mmmd=1)', 'en': 'No complete duplicates detected (Mmmd=1)'},
        'no_dup_groups': {'zh': '未检测到重复样本组', 'en': 'No duplicate groups detected'},

        # === Report Content (CSV columns & categories) ===
        'category_basic': {'zh': '基础信息', 'en': 'Basic Info'},
        'category_algorithm': {'zh': '算法信息', 'en': 'Algorithm Info'},
        'category_validation': {'zh': '数学验证', 'en': 'Math Validation'},
        'category_grading': {'zh': '分级分析', 'en': 'Grading Analysis'},
        'metric_total_samples': {'zh': '分析样本总数(N)', 'en': 'Total Samples (N)'},
        'metric_total_loci': {'zh': '分析标记总数(L)', 'en': 'Total Loci (L)'},
        'metric_marker_type': {'zh': '标记类型', 'en': 'Marker Type'},
        'metric_total_time': {'zh': '总构建耗时(秒)', 'en': 'Total Build Time (s)'},
        'metric_core_algorithm': {'zh': '核心算法', 'en': 'Core Algorithm'},
        'metric_time_complexity': {'zh': '时间复杂度', 'en': 'Time Complexity'},
        'metric_mgi': {'zh': '间隙指数(MGI)', 'en': 'Gap Index (MGI)'},
        'metric_max_mmin': {'zh': '最大Mmin', 'en': 'Max Mmin'},
        'metric_zero_pairs': {'zh': '零错配对数', 'en': 'Zero-Mismatch Pairs'},
        'metric_dup_pairs': {'zh': '重复样本对数', 'en': 'Duplicate Pairs'},
        'metric_dup_groups': {'zh': '重复样本组数', 'en': 'Duplicate Groups'},
        'standard': {'zh': '标准', 'en': 'Standard'},
        'conclusion': {'zh': '结论', 'en': 'Conclusion'},
        'value': {'zh': '值', 'en': 'Value'},
        'metric': {'zh': '指标', 'en': 'Metric'},
        'category': {'zh': '类别', 'en': 'Category'},

        # === Summary Report Text ===
        'report_title': {'zh': '孟德尔错配矩阵体系 (MMM) 分析报告', 'en': 'Mendelian Mismatch Matrix (MMM) Analysis Report'},
        'report_analysis_time': {'zh': '分析时间', 'en': 'Analysis Time'},
        'report_marker_type': {'zh': '标记类型', 'en': 'Marker Type'},
        'report_sample_count': {'zh': '样本数量', 'en': 'Sample Count'},
        'report_locus_count': {'zh': '标记数量', 'en': 'Locus Count'},
        'report_total_time': {'zh': '总耗时', 'en': 'Total Time'},
        'report_validation': {'zh': '五重数学验证', 'en': 'Five-Fold Math Validation'},
        'report_final_conclusion': {'zh': '最终结论', 'en': 'Final Conclusion'},
        'phase1_timing': {'zh': 'Phase 1: 数据加载与格式识别', 'en': 'Phase 1: Data Loading & Format Detection'},
        'phase2_timing': {'zh': 'Phase 2: 构建基因型数组', 'en': 'Phase 2: Building Genotype Array'},
        'phase3_timing': {'zh': 'Phase 3: 计算孟德尔错配矩阵', 'en': 'Phase 3: Calculating Mismatch Matrix'},
        'phase4_timing': {'zh': 'Phase 4: 矩阵验证', 'en': 'Phase 4: Matrix Validation'},
        'phase5_timing': {'zh': 'Phase 5: 计算Dk分级', 'en': 'Phase 5: Calculating Dk Classification'},
        'phase5b_timing': {'zh': 'Phase 5b: 检测零错配对及Mmmd', 'en': 'Phase 5b: Detecting Zero-Mismatch Pairs & Mmmd'},
        'phase6_timing': {'zh': 'Phase 6: 分级分析', 'en': 'Phase 6: Grading Analysis'},
        'phase7_timing': {'zh': 'Phase 7: 生成报告', 'en': 'Phase 7: Generating Report'},
        'report_output_files': {'zh': '输出文件', 'en': 'Output Files'},
        'report_file_desc': {'zh': '文件说明', 'en': 'File Descriptions'},
        'report_note': {'zh': '说明', 'en': 'Note'},
        'report_note_content': {'zh': '本系统执行矩阵构建及自动分级分析', 'en': 'This system performs matrix building and automatic grading analysis'},

        # === Phase Timing ===
        'phase_timing_header': {'zh': '各阶段耗时汇总', 'en': 'Phase Timing Summary'},
        'phase_resource_header': {'zh': '各阶段耗时与资源占用汇总', 'en': 'Phase Timing & Resource Usage Summary'},
        'phase_col_phase': {'zh': '阶段', 'en': 'Phase'},
        'phase_col_time': {'zh': '耗时(秒)', 'en': 'Time(s)'},
        'phase_col_memory': {'zh': '最大内存(MB)', 'en': 'Max Memory(MB)'},
        'phase_col_cpu': {'zh': '最大CPU(%)', 'en': 'Max CPU(%)'},
        'phase_na': {'zh': 'N/A', 'en': 'N/A'},
        'total_time_label': {'zh': '总耗时', 'en': 'Total Time'},
        'output_dir_label': {'zh': '输出目录', 'en': 'Output Directory'},

        # === System Information ===
        'category_system': {'zh': '系统信息', 'en': 'System Information'},
        'category_performance': {'zh': '性能信息', 'en': 'Performance Information'},
        'system_info_header': {'zh': '系统配置信息', 'en': 'System Configuration'},
        'system_os': {'zh': '操作系统', 'en': 'Operating System'},
        'system_cpu_model': {'zh': '处理器型号', 'en': 'CPU Model'},
        'system_physical_cores': {'zh': '物理核心数', 'en': 'Physical Cores'},
        'system_logical_cores': {'zh': '逻辑核心数', 'en': 'Logical Cores'},
        'system_total_memory': {'zh': '总内存', 'en': 'Total Memory'},
        'system_available_memory': {'zh': '可用内存', 'en': 'Available Memory'},
        'system_python_version': {'zh': 'Python版本', 'en': 'Python Version'},
        'system_cpu_frequency': {'zh': 'CPU基准频率', 'en': 'CPU Base Frequency'},
        'software_env_header': {'zh': '软件环境', 'en': 'Software Environment'},
        'lib_numpy_version': {'zh': 'NumPy版本', 'en': 'NumPy Version'},
        'lib_pandas_version': {'zh': 'Pandas版本', 'en': 'Pandas Version'},
        'lib_psutil_version': {'zh': 'psutil版本', 'en': 'psutil Version'},

        # === Performance Metrics for Publication ===
        'performance_header': {'zh': '性能指标（供论文发表参考）', 'en': 'Performance Metrics (for Publication)'},
        'perf_dataset_size': {'zh': '数据集规模', 'en': 'Dataset Size'},
        'perf_total_pairs': {'zh': '成对比较总数', 'en': 'Total Pairwise Comparisons'},
        'perf_total_runtime': {'zh': '总运行时间(秒)', 'en': 'Total Runtime (s)'},
        'perf_throughput_pairs_sec': {'zh': '吞吐量(对/秒)', 'en': 'Throughput (pairs/s)'},
        'perf_time_per_pair_us': {'zh': '每对比较耗时(微秒)', 'en': 'Time per Pair (µs)'},
        'perf_time_per_sample_ms': {'zh': '每样本耗时(毫秒)', 'en': 'Time per Sample (ms)'},
        'perf_peak_memory_mb': {'zh': '峰值内存占用(MB)', 'en': 'Peak Memory Usage (MB)'},
        'perf_peak_cpu_percent': {'zh': '峰值CPU占用(%)', 'en': 'Peak CPU Usage (%)'},
        'perf_chunk_size': {'zh': '分块大小', 'en': 'Chunk Size'},
        'perf_multithreading': {'zh': '多线程', 'en': 'Multithreading'},
        'perf_algorithm_mode': {'zh': '计算模式', 'en': 'Computation Mode'},
        'perf_enabled': {'zh': '启用', 'en': 'Enabled'},
        'perf_disabled': {'zh': '关闭', 'en': 'Disabled'},
        'perf_auto': {'zh': '自动选择', 'en': 'Auto-selected'},

        # === MGI File Content ===
        'mgi_gap_index': {'zh': 'MGI (间隙指数)', 'en': 'MGI (Gap Index)'},
        'mgi_max_mmin': {'zh': '最大Mmin', 'en': 'Max Mmin'},
        'mgi_total_samples': {'zh': '样本总数', 'en': 'Total Samples'},

        # === Dk CSV Columns ===
        'dk_sample_id': {'zh': '样本ID', 'en': 'SampleID'},
        'dk_mmin': {'zh': '最小错配数', 'en': 'Mmin'},
        'dk_mmax': {'zh': '最大错配数(Dk)', 'en': 'Mmax(Dk)'},
        'dk_mavg': {'zh': '平均错配数', 'en': 'Mavg'},
        'dk_mzmp': {'zh': '零错配伙伴数', 'en': 'Mzmp'},
        'dk_mzmp_list': {'zh': '零错配伙伴列表', 'en': 'MzmpList'},

        # === Grading Summary Columns ===
        'gs_grade_k': {'zh': 'Grade_k', 'en': 'Grade_k'},
        'gs_gk_count': {'zh': 'G_k_Count', 'en': 'G_k_Count'},
        'gs_gk_percent': {'zh': 'G_k_Percent', 'en': 'G_k_Percent'},
        'gs_gk_members': {'zh': 'G_k_Members', 'en': 'G_k_Members'},
        'gs_dk_count': {'zh': 'D_k_Count', 'en': 'D_k_Count'},
        'gs_dk_percent': {'zh': 'D_k_Percent', 'en': 'D_k_Percent'},
        'gs_dk_members': {'zh': 'D_k_Members', 'en': 'D_k_Members'},
        'gs_dk_empty': {'zh': 'D_k_Empty', 'en': 'D_k_Empty'},

        # === GUI File Descriptions in Summary ===
        'sum_m_matrix': {'zh': '错配矩阵（N×N对称矩阵，对角线为NA）', 'en': 'Mismatch Matrix (N×N symmetric, diagonal NA)'},
        'sum_l_matrix': {'zh': '有效位点矩阵（N×N矩阵）', 'en': 'Effective Loci Matrix (N×N matrix)'},
        'sum_rate_matrix': {'zh': '孟德尔错配率矩阵（N×N矩阵）', 'en': 'Mendelian Mismatch Rate Matrix (N×N matrix)'},
        'sum_mnp': {'zh': '低错配品种对（M≤2，可用于亲缘分析）', 'en': 'Low-Mismatch Pairs (M≤2, for kinship analysis)'},
        'sum_report': {'zh': '分析报告（运行参数+验证结果+分级概要）', 'en': 'Analysis Report (parameters + validation + summary)'},
        'sum_summary': {'zh': '构建报告（文本格式）', 'en': 'Build Report (text format)'},
        'sum_basic': {'zh': '基础指标表（含Mzmp和零错配伙伴列表）', 'en': 'Basic Metrics (Mzmp & zero-mismatch partners)'},
        'sum_grading': {'zh': '分级汇总表（Dk/Ck各级样本数与成员）', 'en': 'Grading Summary (Dk/Ck counts & members)'},
        'sum_mgi': {'zh': '孟德尔等级间隙指数（分级连续性指标）', 'en': 'Mendelian Grade Gap Index (grading continuity metric)'},
        'sum_zero_pairs': {'zh': '零错配对（Mmmd标记）', 'en': 'Zero-Mismatch Pairs (Mmmd)'},
        'sum_dup_samples': {'zh': '重复样本对（Mmmd=1）', 'en': 'Duplicate Sample Pairs (Mmmd=1)'},
        'sum_dup_groups': {'zh': '重复样本组（并查集合并结果）', 'en': 'Duplicate Sample Groups (Union-Find result)'},
        'sum_only_data': {'zh': '去重后数据（重复组保留首个样本，可直接用于后续分析）', 'en': 'Deduplicated Data (retain first per group for downstream analysis)'},
        'sum_frequency': {'zh': '频率分布（Mmn/Mmin/Mzmp/Mavg）', 'en': 'Frequency Distribution (Mmn/Mmin/Mzmp/Mavg)'},

        # === Report Generator Hardcoded replacements ===
        'sample_insufficient': {'zh': '样本不足', 'en': 'Insufficient Samples'},
        'marker_insufficient': {'zh': '标记不足', 'en': 'Insufficient Loci'},
        'recognized': {'zh': '已识别', 'en': 'Recognized'},
        'vec_parallel_compute': {'zh': '向量化并行计算', 'en': 'Vectorized Parallel Computation'},
        'mmm_compliant': {'zh': '符合MMM标准', 'en': 'MMM Compliant'},
        'optimized': {'zh': '优化后', 'en': 'Optimized'},
        'grading_success_title': {'zh': '分级分析结果', 'en': 'Grading Analysis Results'},
        'stats_zero_dup': {'zh': '{0} 对零错配, {1} 对完全重复 (Mmmd=1)', 'en': '{0} zero-mismatch pairs, {1} complete duplicates (Mmmd=1)'},
    }

    @classmethod
    def set_lang(cls, lang: str):
        """设置当前语言 / Set current language"""
        cls._lang = lang if lang in ('zh', 'en') else 'zh'

    @classmethod
    def get(cls, key: str, *args) -> str:
        """获取翻译文本 / Get translated text"""
        entry = cls._dict.get(key, {})
        text = entry.get(cls._lang, entry.get('zh', key))
        if args:
            text = text.format(*args)
        return text

    @classmethod
    def current(cls) -> str:
        """返回当前语言代码 / Return current language code"""
        return cls._lang


def t(key: str, *args) -> str:
    """快捷获取翻译文本 / Quick access to translated text"""
    return I18n.get(key, *args)




# =============================================================================
# 第一部分：全局配置与常量 / Part 1: Global Configuration & Constants
# =============================================================================

# 缺失值定义
MISSING_VALUES = [None, '', 'na', 'nan', 'NA', 'NaN', 'null', 'NULL',
                  '0', './.', '-', '.', '-9', '-1', '000', '999', '9999']

# SNP格式的特殊处理：0是有效基因型，不是缺失值
SNP_MISSING_VALUES = [mv for mv in MISSING_VALUES if mv != '0']

# 输出文件名统一规范
OUTPUT_FILES = {
    'mmm_matrix': 'MMM_Matrix.csv',
    'valid_matrix': 'MMM_Effective_Loci_Matrix.csv',
    'mismatch_rate_matrix': 'MMM_Mmr_Matrix.csv',
    'mnp_pairs': 'MMM_Mnp_Mismatch_Pairs.csv',
    'report': 'MMM_Analytical_Report.csv',
    'summary': 'MMM_Build_Report.txt',
    'basic': 'MMM_basic.csv',
    'grading_summary': 'MMM_Grading_Summary.csv',
    'mgi': 'MMM_MGI.txt',
    'zero_pairs': 'MMM_Zero_Mismatch_Pairs.csv',
    'duplicate_samples': 'MMM_Duplicate_Samples.csv',
    'duplicate_groups': 'MMM_Duplicate_Groups.csv',
    'only_data': 'MMM_only_data.csv',
    'frequency': 'MMM_frequency.csv',
}

# 性能配置
MAX_WORKERS = min(multiprocessing.cpu_count(), 8)
DEFAULT_CHUNK_SIZE = 500

# GUI 常量
GUI_FONT_TITLE = ('Microsoft YaHei', 14, 'bold')
GUI_FONT_LABEL = ('Microsoft YaHei', 9)
GUI_FONT_MONO = ('Consolas', 10)

# 数值常量
NAN_THRESHOLD = 1e-6
MAX_SMALL_NETWORK = 80
MAX_LARGE_NETWORK = 50

# 列名常量
COLUMN_SAMPLEID = 'SampleID'
COLUMN_MMIN = 'Mmin'
COLUMN_MMAX = 'Mmax'
COLUMN_MAVG = 'Mavg'
COLUMN_MZMP = 'Mzmp'
COLUMN_MMMD = 'Mmmd'


# =============================================================================
# 第二部分：异常类 / Part 2: Exception Classes
# =============================================================================

class MMMException(Exception):
    """MMM工具基异常 / MMM Base Exception"""
    pass

class DataFormatError(MMMException):
    """数据格式错误 / Data Format Error"""
    pass

class AnalysisError(MMMException):
    """分析执行错误 / Analysis Execution Error"""
    pass

class ExportError(MMMException):
    """导出操作错误 / Export Operation Error"""
    pass


# =============================================================================
# 第三部分：数据结构定义 / Part 3: Data Structure Definitions
# =============================================================================

@dataclass
class MMMConfig:
    """MMM分析配置 / MMM Analysis Configuration"""
    input_file: str
    output_dir: str
    marker_type: Optional[str] = None
    chunk_size: int = DEFAULT_CHUNK_SIZE
    use_multithreading: bool = True
    enable_checkpoint: bool = True
    min_valid_loci_ratio: float = 0.8
    auto_grading: bool = True


@dataclass
class MMMResults:
    """MMM分析结果容器 / MMM Analysis Results Container"""
    incomp_mat: np.ndarray = field(default_factory=lambda: np.array([]))
    valid_mat: np.ndarray = field(default_factory=lambda: np.array([]))
    sample_ids: List[str] = field(default_factory=list)
    locus_names: List[str] = field(default_factory=list)
    marker_type: str = ''
    n_samples: int = 0
    n_loci: int = 0
    dk_classification: Dict = field(default_factory=dict)
    validation_report: Dict = field(default_factory=dict)
    quality_report: Optional[Dict] = None
    timestamps: Dict = field(default_factory=dict)
    fingerprint: Dict = field(default_factory=dict)
    grading_result: Dict = field(default_factory=dict)
    zero_mismatch_pairs: Optional[pd.DataFrame] = None


# =============================================================================
# 第四部分：格式检测器 / Part 4: Format Detector
# =============================================================================

class DataStructureDetector:
    """数据结构检测器 / Data Structure Detector"""

    FORMAT_PATTERNS = {
        'slash': re.compile(r'^(\d+)/(\d+)$'),
        'dash': re.compile(r'^(\d+)-(\d+)$'),
        'space': re.compile(r'^(\d+)\s+(\d+)$'),
        'snp_012': re.compile(r'^[012]$'),
    }

    @classmethod
    def _is_format_c(cls, df: pd.DataFrame) -> bool:
        """检测SSR原始数据格式（双表头）：第一行为位点名，第二行为Allele1/Allele2

        pandas 读取重复列名时会自动添加 .1 后缀，因此通过以下特征综合判断：
        1. 列数 >= 3，且除首列外有偶数列
        2. 第二行（CSV中真正的第二行，即 df.iloc[0]）除首列外为 Allele1/Allele2 交替
        3. 第三行（df.iloc[1]）为实际样本数据
        """
        if df.shape[0] < 2 or df.shape[1] < 3:
            return False
        n_data_cols = df.shape[1] - 1
        if n_data_cols % 2 != 0:
            return False
        # df.iloc[0] 对应 CSV 第二行（Allele1/Allele2 表头行）
        first_data_row = df.iloc[0].astype(str).str.strip().str.lower().tolist()[1:]
        allele_labels = {'allele1', 'allele2'}
        if len(first_data_row) < 2:
            return False
        if not all(v in allele_labels for v in first_data_row[:min(len(first_data_row), 20)]):
            return False
        # 第三行（df.iloc[1]）应为实际样本数据
        second_data_row = df.iloc[1].astype(str).str.strip().tolist()[1:]
        numeric_count = sum(1 for v in second_data_row[:min(len(second_data_row), 20)] if v.isdigit())
        return numeric_count >= len(second_data_row[:min(len(second_data_row), 20)]) * 0.5

    @classmethod
    def preprocess_format_c(cls, df: pd.DataFrame) -> pd.DataFrame:
        """预处理格式C：删除Allele表头行，并将列名规范化为 Locus_1 / Locus_2"""
        df = df.iloc[1:].reset_index(drop=True)
        header_cols = df.columns.tolist()
        new_cols = [str(header_cols[0]).strip()]

        i = 1
        while i < len(header_cols):
            col = str(header_cols[i]).strip()
            # pandas 遇到重复列名会自动添加 .1 后缀
            next_col = str(header_cols[i + 1]).strip() if i + 1 < len(header_cols) else None
            if next_col == f"{col}.1":
                new_cols.extend([f"{col}_1", f"{col}_2"])
                i += 2
            else:
                # 回退：按原列名加后缀
                new_cols.append(f"{col}_1")
                if i + 1 < len(header_cols):
                    next_col = str(header_cols[i + 1]).strip()
                    new_cols.append(f"{next_col}_2")
                    i += 2
                else:
                    i += 1
        df.columns = new_cols
        return df

    @classmethod
    def detect_format(cls, df: pd.DataFrame) -> str:
        """检测数据格式类型"""
        if df.shape[1] < 2:
            return 'unknown'

        # 检测格式C（SSR原始双表头格式），需在 sample_data 检测前完成
        if cls._is_format_c(df):
            return 'format_c'

        sample_data = df.iloc[:, 1:].iloc[0].dropna().astype(str).tolist()
        if not sample_data:
            return 'unknown'

        # 检测1: 是否含斜杠分隔符
        slash_count = sum(1 for v in sample_data if '/' in str(v))
        if slash_count >= len(sample_data) * 0.5:
            return 'original'

        # 检测2: 分列格式
        cols = df.columns.tolist()[1:]
        if len(cols) >= 2:
            paired_count = 0
            for i in range(0, min(len(cols)-1, 20), 2):
                col1, col2 = str(cols[i]), str(cols[i+1])
                if (col1.endswith('_1') and col2.endswith('_2') and col1[:-2] == col2[:-2]) or \
                   (col1.endswith('.1') and col2.endswith('.2') and col1[:-2] == col2[:-2]) or \
                   (col1.endswith('_a') and col2.endswith('_b') and col1[:-2] == col2[:-2]) or \
                   (col2 == col1 + '.1'):
                    paired_count += 1
                elif re.match(r'^.+_[aA]$', col1) and re.match(r'^.+_[bB]$', col2):
                    root1, root2 = col1[:-2], col2[:-2]
                    if root1 == root2:
                        paired_count += 1

            if paired_count > 0 and paired_count >= len(cols) // 4:
                return 'reformatted'

        # 检测3: SNP格式 (0/1/2)
        all_values = set()
        for col in df.columns[1:]:
            for v in df[col].dropna().astype(str).values[:100]:
                v_clean = v.strip()
                if v_clean.lower() not in ('na', 'nan', '', 'none', 'null', './.', '-', '.'):
                    try:
                        v_int = str(int(float(v_clean)))
                        all_values.add(v_int)
                    except:
                        all_values.add(v_clean)
                        break

        if all_values and all_values.issubset({'0', '1', '2'}):
            return 'snp'

        # 检测4: 转置碱基型SNP格式 (行=位点, 列=样本, 值=CC/TC/TT等)
        sample_vals = []
        for col in df.columns[1:min(20, len(df.columns))]:
            sample_vals.extend(df[col].dropna().astype(str).values[:50])

        if sample_vals:
            base_chars = {'A', 'T', 'C', 'G', 'N', 'R', 'Y', 'K', 'M', 'S', 'W', 'H', 'B', 'V', 'D'}
            two_base_count = sum(1 for v in sample_vals if len(str(v).strip()) == 2
                                  and all(ch.upper() in base_chars for ch in str(v).strip()))
            if two_base_count / len(sample_vals) > 0.8:
                return 'transposed_base_snp'

        return 'unknown'

    @classmethod
    def detect_structure(cls, df: pd.DataFrame, format_type: str) -> Dict:
        """根据格式类型提取数据结构信息"""
        sample_ids = df.iloc[:, 0].astype(str).tolist()
        data_cols = df.columns[1:].tolist()

        locus_map = {}
        locus_roots = []

        if format_type == 'reformatted':
            processed = set()
            i = 0
            while i < len(data_cols):
                if i in processed:
                    i += 1
                    continue

                col = data_cols[i]
                col_str = str(col)

                # 优先检测 root/root.1 格式
                if i + 1 < len(data_cols):
                    next_col = str(data_cols[i + 1])
                    if next_col == col_str + '.1' or next_col == col_str + '.2':
                        locus_map[col_str] = [col, data_cols[i + 1]]
                        locus_roots.append(col_str)
                        processed.add(i)
                        processed.add(i + 1)
                        i += 2
                        continue

                # 尝试匹配 _1/_2, .1/.2, _a/_b, _A/_B 模式
                match = re.match(r'^(.+?)(?:_1|_2|\.1|\.2|_a|_b|_A|_B)$', col_str)
                if match:
                    root = match.group(1)
                    if root not in locus_map:
                        pair_cols = []
                        for suffix in ['_1', '_2']:
                            test_col = root + suffix
                            if test_col in data_cols:
                                pair_cols.append(test_col)
                        if len(pair_cols) == 2:
                            locus_map[root] = pair_cols
                            locus_roots.append(root)
                            processed.add(data_cols.index(pair_cols[0]))
                            processed.add(data_cols.index(pair_cols[1]))
                        else:
                            pair_cols = []
                            for suffix in ['.1', '.2']:
                                test_col = root + suffix
                                if test_col in data_cols:
                                    pair_cols.append(test_col)
                            if len(pair_cols) == 2:
                                locus_map[root] = pair_cols
                                locus_roots.append(root)
                                for pc in pair_cols:
                                    if pc in data_cols:
                                        processed.add(data_cols.index(pc))
                            else:
                                # 尝试 _a/_b 或 _A/_B
                                for suffix_pair in [['_a', '_b'], ['_A', '_B']]:
                                    pair_cols = []
                                    for suffix in suffix_pair:
                                        test_col = root + suffix
                                        if test_col in data_cols:
                                            pair_cols.append(test_col)
                                    if len(pair_cols) == 2:
                                        locus_map[root] = pair_cols
                                        locus_roots.append(root)
                                        processed.add(data_cols.index(pair_cols[0]))
                                        processed.add(data_cols.index(pair_cols[1]))
                                        break
                else:
                    # 尝试明确的 a/b 后缀
                    match = re.match(r'^(.+?)(?:_a|_b|\.a|\.b|_A|_B|\.A|\.B)$', col_str)
                    if match and i + 1 < len(data_cols):
                        root = match.group(1)
                        next_col = str(data_cols[i + 1])
                        if re.match(rf'^{re.escape(root)}(_[bB]|\.[bB])$', next_col):
                            if root not in locus_map:
                                locus_map[root] = [col, data_cols[i + 1]]
                                locus_roots.append(root)
                                processed.add(i)
                                processed.add(i + 1)
                i += 1

        elif format_type in ('snp', 'original'):
            locus_roots = data_cols
            for col in data_cols:
                locus_map[col] = col

        elif format_type == 'transposed_base_snp':
            # 转置碱基型 SNP 格式：行=位点，列=样本
            locus_roots = df.iloc[:, 0].astype(str).str.strip().tolist()
            sample_ids = [str(c).strip() for c in data_cols]
            locus_map = {col: col for col in locus_roots}

        return {
            'sample_ids': sample_ids,
            'n_samples': len(sample_ids),
            'locus_map': locus_map,
            'n_loci': len(locus_roots),
            'locus_names': locus_roots,
            'format_type': format_type
        }


# =============================================================================
# 第五部分：标记类型检测器 / Part 5: Marker Type Detector
# =============================================================================

class MarkerTypeDetector:
    """自动识别 SSR/SNP 标记类型 / Auto-detect SSR/SNP Marker Type"""

    @staticmethod
    def detect(df: pd.DataFrame, structure_info: Dict) -> str:
        """自动检测标记类型"""
        format_type = structure_info.get('format_type', 'unknown')
        if format_type in ('snp', 'transposed_base_snp'):
            return 'SNP'

        all_values = set()
        data_cols = df.columns[1:].tolist()
        sample_cols = data_cols[:min(20, len(data_cols))]

        for col in sample_cols:
            for val in df[col].dropna().values:
                val_str = str(val).strip()
                if '/' in val_str:
                    parts = val_str.split('/')
                    all_values.update(parts)
                else:
                    all_values.add(val_str)

        all_values = {v for v in all_values if v not in MISSING_VALUES}
        is_012 = all_values.issubset({'0', '1', '2'})

        numeric_values = []
        for v in all_values:
            try:
                numeric_values.append(int(float(v)))
            except:
                pass

        if numeric_values:
            max_val = max(numeric_values)
            min_val = min(numeric_values)
            value_range = max_val - min_val
        else:
            max_val = min_val = value_range = 0

        high_loci_count = structure_info.get('n_loci', 0) > 50

        score_snp = 0
        score_ssr = 0

        if is_012:
            score_snp += 3
        if numeric_values and value_range <= 2:
            score_snp += 2
        if high_loci_count:
            score_snp += 1
        if format_type == 'original':
            score_ssr += 1
        if numeric_values and max_val > 100:
            score_ssr += 2

        return 'SNP' if score_snp > score_ssr else 'SSR'


# =============================================================================
# 第六部分：基因型处理器 / Part 6: Genotype Processor
# =============================================================================

class GenotypeProcessor:
    """基因型处理器 / Genotype Processor - Supports SSR and SNP"""

    @staticmethod
    def _standardize_value(val, marker_type: str = 'SSR') -> str:
        """标准化值为字符串"""
        if pd.isna(val):
            return ''
        val_str = str(val).strip()
        try:
            fval = float(val_str)
            if marker_type == 'SSR' and fval != int(fval):
                return val_str
            return str(int(fval))
        except (ValueError, TypeError):
            return val_str

    @classmethod
    def build_geno_array(cls, df: pd.DataFrame, structure: Dict, marker_type: str) -> Tuple[np.ndarray, np.ndarray]:
        """构建基因型数组"""
        n = structure['n_samples']
        n_loci = structure['n_loci']
        locus_names = structure['locus_names']
        format_type = structure['format_type']

        geno_array = np.full((n, n_loci, 2), None, dtype=object)

        if format_type == 'reformatted':
            for i, loc in enumerate(locus_names):
                cols = structure['locus_map'][loc]
                geno_array[:, i, 0] = df[cols[0]].apply(cls._standardize_value).values
                geno_array[:, i, 1] = df[cols[1]].apply(cls._standardize_value).values

        elif format_type == 'snp':
            for i, loc in enumerate(locus_names):
                col_data = df[loc].apply(lambda x: cls._standardize_value(x, marker_type='SNP')).values
                for j, val in enumerate(col_data):
                    if val == '0':
                        geno_array[j, i] = ['0', '0']
                    elif val == '1':
                        geno_array[j, i] = ['0', '1']
                    elif val == '2':
                        geno_array[j, i] = ['1', '1']
                    else:
                        geno_array[j, i] = [val, val]

        elif format_type == 'transposed_base_snp':
            # 转置碱基型 SNP 格式：行=位点，列=样本
            # geno_array 形状为 (n_samples, n_loci, 2)
            # i = 样本索引(列), j = 位点索引(行)
            data_cols = df.columns[1:]
            for i, sample_col in enumerate(data_cols):
                col_data = df[sample_col].apply(cls._standardize_value).values
                for j, val in enumerate(col_data):
                    val = str(val).strip()
                    if '/' in val:
                        parts = val.split('/')
                        geno_array[i, j] = [parts[0].strip(), parts[1].strip()]
                    elif len(val) == 2:
                        geno_array[i, j] = [val[0], val[1]]
                    elif len(val) == 1:
                        geno_array[i, j] = [val, val]
                    else:
                        geno_array[i, j] = [val, val]

        else:  # original格式
            for i, loc in enumerate(locus_names):
                col_data = df[loc].apply(lambda x: cls._standardize_value(x, marker_type=marker_type)).values
                for j, val in enumerate(col_data):
                    if '/' in val:
                        parts = val.split('/')
                        geno_array[j, i] = [parts[0].strip(), parts[1].strip()]
                    elif '-' in val and not val.startswith('-'):
                        parts = val.split('-')
                        geno_array[j, i] = [parts[0].strip(), parts[1].strip()]
                    else:
                        geno_array[j, i] = [val, val]

        # 构建缺失值掩码
        missing_mask = np.zeros((n, n_loci), dtype=bool)
        missing_values = SNP_MISSING_VALUES if marker_type == 'SNP' else MISSING_VALUES

        for mv in missing_values:
            missing_mask |= (geno_array[:, :, 0] == mv) | (geno_array[:, :, 1] == mv)

        missing_mask |= (geno_array[:, :, 0] == '') | (geno_array[:, :, 1] == '')

        return geno_array, missing_mask

    @staticmethod
    def is_mismatch(g1: Tuple, g2: Tuple) -> bool:
        """判断两个基因型是否存在孟德尔错配"""
        if any(v is None or v == '' for v in [g1[0], g1[1], g2[0], g2[1]]):
            return False

        g1_set = set(g1)
        g2_set = set(g2)
        return len(g1_set & g2_set) == 0



# =============================================================================
# 第七部分：错配矩阵计算器 / Part 7: Mismatch Matrix Calculator
# =============================================================================

class MismatchCalculator:
    """孟德尔错配矩阵计算器 / Mendelian Mismatch Matrix Calculator"""

    def __init__(self, geno_array: np.ndarray, missing_mask: np.ndarray):
        self.geno_array = geno_array
        self.missing_mask = missing_mask
        self.n_samples = geno_array.shape[0]
        self.n_loci = geno_array.shape[1]

    def calculate_standard(self, progress_callback: Optional[Callable] = None) -> Tuple[np.ndarray, np.ndarray]:
        """标准算法（三重循环）- 适用于小规模数据集"""
        n, n_loci = self.n_samples, self.n_loci
        incomp_mat = np.zeros((n, n), dtype=np.int32)
        valid_mat = np.zeros((n, n), dtype=np.int32)

        total_pairs = n * (n - 1) // 2
        processed = 0

        for i in range(n - 1):
            for j in range(i + 1, n):
                mismatch_count = 0
                valid_count = 0

                for l in range(n_loci):
                    if not self.missing_mask[i, l] and not self.missing_mask[j, l]:
                        valid_count += 1
                        if GenotypeProcessor.is_mismatch(
                            tuple(self.geno_array[i, l]),
                            tuple(self.geno_array[j, l])
                        ):
                            mismatch_count += 1

                incomp_mat[i, j] = incomp_mat[j, i] = mismatch_count
                valid_mat[i, j] = valid_mat[j, i] = valid_count

                processed += 1
                if progress_callback and processed % 1000 == 0:
                    progress_callback(processed / total_pairs * 100)

        return incomp_mat, valid_mat

    def calculate_vectorized(self, progress_callback: Optional[Callable] = None) -> Tuple[np.ndarray, np.ndarray]:
        """向量化算法 - 中等规模数据集"""
        n = self.n_samples
        allele1, allele2 = self._encode_alleles()

        incomp_mat = np.zeros((n, n), dtype=np.int32)
        valid_mat = np.zeros((n, n), dtype=np.int32)

        total_pairs = n * (n - 1) // 2
        processed = 0
        block_size = 128

        for i_start in range(0, n - 1, block_size):
            i_end = min(i_start + block_size, n)

            for j_start in range(i_start + 1, n, block_size):
                j_end = min(j_start + block_size, n)

                a1_i = allele1[i_start:i_end]
                a2_i = allele2[i_start:i_end]
                m_i = self.missing_mask[i_start:i_end]

                a1_j = allele1[j_start:j_end]
                a2_j = allele2[j_start:j_end]
                m_j = self.missing_mask[j_start:j_end]

                ni, nj = i_end - i_start, j_end - j_start

                valid_i = ~m_i
                valid_j = ~m_j
                valid_both = valid_i[:, None, :] & valid_j[None, :, :]
                L_block = np.sum(valid_both, axis=2)

                share1 = (a1_i[:, None, :] == a1_j[None, :, :]) | (a1_i[:, None, :] == a2_j[None, :, :])
                share2 = (a2_i[:, None, :] == a1_j[None, :, :]) | (a2_i[:, None, :] == a2_j[None, :, :])
                has_share = share1 | share2

                M_block = L_block - np.sum(has_share & valid_both, axis=2)

                for ii in range(ni):
                    i_global = i_start + ii
                    for jj in range(nj):
                        j_global = j_start + jj
                        if j_global <= i_global:
                            continue
                        incomp_mat[i_global, j_global] = incomp_mat[j_global, i_global] = int(M_block[ii, jj])
                        valid_mat[i_global, j_global] = valid_mat[j_global, i_global] = int(L_block[ii, jj])
                        processed += 1

                if progress_callback and processed % 1000 == 0:
                    progress_callback(processed / total_pairs * 100)

        return incomp_mat, valid_mat

    @staticmethod
    def _encode_alleles_static(geno_array: np.ndarray, missing_mask: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """将等位基因编码为整数"""
        n, n_loci = geno_array.shape[0], geno_array.shape[1]
        allele1 = np.full((n, n_loci), -1, dtype=np.int32)
        allele2 = np.full((n, n_loci), -1, dtype=np.int32)

        for l in range(n_loci):
            allele_map = {}
            next_code = 0
            for i in range(n):
                if missing_mask[i, l]:
                    continue
                a1 = geno_array[i, l, 0]
                a2 = geno_array[i, l, 1]
                if a1 not in allele_map:
                    allele_map[a1] = next_code
                    next_code += 1
                allele1[i, l] = allele_map[a1]
                if a2 not in allele_map:
                    allele_map[a2] = next_code
                    next_code += 1
                allele2[i, l] = allele_map[a2]

        return allele1, allele2

    def _encode_alleles(self) -> Tuple[np.ndarray, np.ndarray]:
        return self._encode_alleles_static(self.geno_array, self.missing_mask)


# =============================================================================
# 第八部分：高性能并行计算器 / Part 8: High-Performance Parallel Calculator
# =============================================================================

class ParallelMMMCalculator:
    """高性能并行MMM矩阵计算器 / High-Performance Parallel MMM Calculator"""

    def __init__(self, checkpoint_dir: Optional[str] = None):
        self.checkpoint_dir = checkpoint_dir
        if checkpoint_dir:
            os.makedirs(checkpoint_dir, exist_ok=True)

    def calculate(self, geno_array: np.ndarray, missing_mask: np.ndarray,
                  progress_callback: Optional[Callable] = None,
                  use_multithreading: bool = True,
                  chunk_size: int = DEFAULT_CHUNK_SIZE,
                  M_matrix: Optional[np.ndarray] = None,
                  Lij_matrix: Optional[np.ndarray] = None) -> Tuple[np.ndarray, np.ndarray]:
        """并行计算错配矩阵

        如果传入 M_matrix / Lij_matrix（可以是 np.ndarray 或 np.memmap），
        则结果直接写入其中；否则在内存中新建矩阵并返回。
        """
        n = geno_array.shape[0]
        allele1, allele2 = self._encode_alleles(geno_array, missing_mask)

        if M_matrix is None:
            M_matrix = np.full((n, n), np.nan, dtype=np.float32)
        if Lij_matrix is None:
            Lij_matrix = np.full((n, n), np.nan, dtype=np.float32)

        tasks = []
        for i_start in range(0, n, chunk_size):
            i_end = min(i_start + chunk_size, n)
            for j_start in range(i_start, n, chunk_size):
                j_end = min(j_start + chunk_size, n)
                tasks.append((allele1, allele2, missing_mask, i_start, i_end, j_start, j_end))

        total_tasks = len(tasks)
        completed = 0

        if use_multithreading and total_tasks > 1:
            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                futures = {executor.submit(self._compute_block, task): task for task in tasks}
                for future in as_completed(futures):
                    (i_start, j_start), M_block, L_block = future.result()
                    i_end = i_start + M_block.shape[0]
                    j_end = j_start + M_block.shape[1]

                    M_matrix[i_start:i_end, j_start:j_end] = M_block
                    Lij_matrix[i_start:i_end, j_start:j_end] = L_block

                    if i_start != j_start:
                        M_matrix[j_start:j_end, i_start:i_end] = M_block.T
                        Lij_matrix[j_start:j_end, i_start:i_end] = L_block.T

                    completed += 1
                    if progress_callback:
                        progress_callback(completed / total_tasks * 100)
        else:
            for task in tasks:
                (i_start, j_start), M_block, L_block = self._compute_block(task)
                i_end = i_start + M_block.shape[0]
                j_end = j_start + L_block.shape[1]

                M_matrix[i_start:i_end, j_start:j_end] = M_block
                Lij_matrix[i_start:i_end, j_start:j_end] = L_block

                if i_start != j_start:
                    M_matrix[j_start:j_end, i_start:i_end] = M_block.T
                    Lij_matrix[j_start:j_end, i_start:i_end] = L_block.T

                completed += 1
                if progress_callback:
                    progress_callback(completed / total_tasks * 100)

        np.fill_diagonal(M_matrix, np.nan)
        np.fill_diagonal(Lij_matrix, np.nan)

        return M_matrix, Lij_matrix

    def _encode_alleles(self, geno_array: np.ndarray, missing_mask: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        return MismatchCalculator._encode_alleles_static(geno_array, missing_mask)

    def _compute_block(self, args) -> Tuple[Tuple[int, int], np.ndarray, np.ndarray]:
        """计算矩阵块"""
        allele1, allele2, missing_mask, i_start, i_end, j_start, j_end = args

        a1_i = allele1[i_start:i_end]
        a2_i = allele2[i_start:i_end]
        a1_j = allele1[j_start:j_end]
        a2_j = allele2[j_start:j_end]
        m_i = missing_mask[i_start:i_end]
        m_j = missing_mask[j_start:j_end]

        ni, nj = i_end - i_start, j_end - j_start
        n_loci = allele1.shape[1]

        M_block = np.zeros((ni, nj), dtype=np.float32)
        L_block = np.zeros((ni, nj), dtype=np.float32)

        for l in range(n_loci):
            valid_i = ~m_i[:, l]
            valid_j = ~m_j[:, l]
            valid_both = valid_i[:, None] & valid_j[None, :]

            share1 = (a1_i[:, l:l+1] == a1_j[None, :, l]) | (a1_i[:, l:l+1] == a2_j[None, :, l])
            share2 = (a2_i[:, l:l+1] == a1_j[None, :, l]) | (a2_i[:, l:l+1] == a2_j[None, :, l])
            has_share = share1 | share2

            mismatch = valid_both & ~has_share

            M_block += mismatch.astype(np.float32)
            L_block += valid_both.astype(np.float32)

        return (i_start, j_start), M_block, L_block


# =============================================================================
# 第八部分（附）：性能与资源监控器 / Part 8b: Performance & Resource Monitor
# =============================================================================

class PerformanceMonitor:
    """轻量级进程资源监控器 / Lightweight process resource monitor

    在后台线程中定期采样当前进程的内存(RSS)和CPU占用率，
    记录每个阶段的最大值。若 psutil 不可用则静默回退。
    """

    def __init__(self, interval: float = 0.05):
        self.interval = interval
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._process: Optional[psutil.Process] = None
        self._max_memory_mb = 0.0
        self._max_cpu_percent = 0.0
        self._available = psutil is not None
        self._cpu_count = psutil.cpu_count() if psutil else 1
        if self._cpu_count is None or self._cpu_count < 1:
            self._cpu_count = 1

    def _capture(self, process: psutil.Process):
        """单次采样并更新最大值

        psutil 的 cpu_percent 默认按单核计算，多核满载时会超过 100%。
        这里除以逻辑核心数，转换为进程占用的总体 CPU 百分比（0~100%）。
        """
        try:
            mem_mb = process.memory_info().rss / (1024 * 1024)
            cpu_percent = process.cpu_percent(interval=None) / self._cpu_count
            self._max_memory_mb = max(self._max_memory_mb, mem_mb)
            self._max_cpu_percent = max(self._max_cpu_percent, cpu_percent)
        except Exception:
            pass

    def _sample(self):
        """后台采样循环"""
        if self._process is None:
            return
        # 初始化 CPU 采样基准
        try:
            self._process.cpu_percent(interval=None)
        except Exception:
            pass

        while not self._stop_event.is_set():
            self._capture(self._process)
            time.sleep(self.interval)

    def start(self):
        """启动监控线程"""
        if not self._available:
            return
        try:
            self._process = psutil.Process(os.getpid())
        except Exception:
            return
        self._stop_event.clear()
        self._max_memory_mb = 0.0
        self._max_cpu_percent = 0.0
        self._thread = threading.Thread(target=self._sample, daemon=True)
        self._thread.start()

    def stop(self):
        """停止监控线程并执行最终采样"""
        if not self._available or self._thread is None:
            return
        self._stop_event.set()
        self._thread.join(timeout=self.interval * 3)
        # 最终采样：确保短阶段也能捕获资源占用
        if self._process is not None:
            self._capture(self._process)
        self._thread = None

    @property
    def max_memory_mb(self) -> float:
        return self._max_memory_mb

    @property
    def max_cpu_percent(self) -> float:
        return self._max_cpu_percent


@contextmanager
def phase_profiler(timings: Dict, resources: Dict, phase_key: str):
    """阶段性能分析上下文管理器 / Phase profiling context manager

    自动记录阶段耗时以及该阶段内的最大内存和 CPU 占用。
    """
    monitor = PerformanceMonitor()
    monitor.start()
    start_time = time.time()
    try:
        yield
    finally:
        elapsed = time.time() - start_time
        monitor.stop()
        timings[phase_key] = elapsed
        resources[phase_key] = {
            'max_memory_mb': round(monitor.max_memory_mb, 2),
            'max_cpu_percent': round(monitor.max_cpu_percent, 2),
        }


def _get_cpu_model() -> str:
    """获取 CPU 型号名称（跨平台最佳 effort）"""
    proc = platform.processor()
    if proc and proc not in ('x86_64', 'AMD64', 'i386', 'i686'):
        return proc

    if sys.platform == 'win32':
        # 优先使用 PowerShell 获取友好 CPU 名称（wmic 在新版 Windows 中已弃用）
        try:
            import subprocess
            output = subprocess.check_output(
                ['powershell.exe', '-NoProfile', '-Command',
                 'Get-CimInstance Win32_Processor | Select-Object -ExpandProperty Name'],
                stderr=subprocess.DEVNULL, text=True, timeout=5
            ).strip()
            if output:
                return output
        except Exception:
            pass

        # 回退到 wmic
        try:
            import subprocess
            output = subprocess.check_output(
                ['wmic', 'cpu', 'get', 'Name', '/value'],
                stderr=subprocess.DEVNULL, text=True, timeout=5
            ).strip()
            for line in output.splitlines():
                if line.startswith('Name='):
                    name = line.split('=', 1)[1].strip()
                    if name:
                        return name
        except Exception:
            pass

    if sys.platform.startswith('linux'):
        try:
            with open('/proc/cpuinfo', 'r', encoding='utf-8') as f:
                for line in f:
                    if line.startswith('model name'):
                        return line.split(':', 1)[1].strip()
        except Exception:
            pass

    if sys.platform == 'darwin':
        try:
            import subprocess
            output = subprocess.check_output(
                ['sysctl', '-n', 'machdep.cpu.brand_string'],
                stderr=subprocess.DEVNULL, text=True, timeout=5
            ).strip()
            if output:
                return output
        except Exception:
            pass

    return 'Unknown'


def get_system_info() -> Dict[str, str]:
    """获取系统配置信息 / Get system configuration information"""
    info: Dict[str, str] = {
        'os': platform.platform(),
        'cpu_model': _get_cpu_model(),
        'cpu_frequency_mhz': 'N/A',
        'physical_cores': str(psutil.cpu_count(logical=False)) if psutil else 'N/A',
        'logical_cores': str(psutil.cpu_count(logical=True)) if psutil else 'N/A',
        'total_memory_gb': 'N/A',
        'available_memory_gb': 'N/A',
        'python_version': platform.python_version(),
        'numpy_version': np.__version__,
        'pandas_version': pd.__version__,
        'psutil_version': psutil.__version__ if psutil else 'N/A',
    }
    if psutil:
        try:
            total_bytes = psutil.virtual_memory().total
            info['total_memory_gb'] = f"{total_bytes / (1024 ** 3):.2f}"
            avail_bytes = psutil.virtual_memory().available
            info['available_memory_gb'] = f"{avail_bytes / (1024 ** 3):.2f}"
        except Exception:
            pass
        try:
            freq = psutil.cpu_freq()
            if freq and freq.max:
                info['cpu_frequency_mhz'] = f"{freq.max:.0f}"
        except Exception:
            pass
    return info


def _get_available_memory_bytes() -> int:
    """获取当前可用内存（字节）"""
    if psutil:
        try:
            return int(psutil.virtual_memory().available)
        except Exception:
            pass
    return 4 * (1024 ** 3)  # 默认保守估计 4GB


def _estimate_matrix_memory(n: int, dtype: np.dtype) -> int:
    """估算单个 N×N 矩阵所需内存（字节）"""
    return n * n * np.dtype(dtype).itemsize


def _requires_mmap(n: int, n_matrices: int = 2, dtype: np.dtype = np.float32,
                   safety_factor: float = 0.5) -> bool:
    """判断是否需要使用内存映射矩阵

    当多个 N×N 矩阵的总预估内存超过可用内存的安全比例时，启用 mmap。
    """
    avail = _get_available_memory_bytes()
    needed = _estimate_matrix_memory(n, dtype) * n_matrices
    return needed > avail * safety_factor


def create_mmap_matrix(filename: str, shape: Tuple[int, int],
                       dtype: np.dtype, fill_value=0) -> np.memmap:
    """创建内存映射矩阵文件"""
    mm = np.memmap(filename, dtype=dtype, mode='w+', shape=shape)
    mm[:] = fill_value
    mm.flush()
    return mm


def get_performance_metrics(results: MMMResults, total_time: float,
                            config: 'MMMConfig') -> Dict[str, str]:
    """计算供论文发表使用的性能指标 / Compute publication-ready performance metrics"""
    n = results.n_samples
    l = results.n_loci
    total_pairs = max(1, n * (n - 1) // 2)

    peak_mem = 0.0
    peak_cpu = 0.0
    phase_resources = results.timestamps.get('phase_resources', {})
    for res in phase_resources.values():
        if isinstance(res, dict):
            peak_mem = max(peak_mem, res.get('max_memory_mb', 0.0))
            peak_cpu = max(peak_cpu, res.get('max_cpu_percent', 0.0))

    throughput = total_pairs / total_time if total_time > 0 else 0.0
    time_per_pair_us = (total_time * 1e6) / total_pairs if total_pairs > 0 else 0.0
    time_per_sample_ms = (total_time * 1e3) / n if n > 0 else 0.0

    return {
        'dataset_size': f"{n} × {l}",
        'total_pairs': str(total_pairs),
        'total_runtime_s': f"{total_time:.3f}",
        'throughput_pairs_sec': f"{throughput:,.0f}",
        'time_per_pair_us': f"{time_per_pair_us:.2f}",
        'time_per_sample_ms': f"{time_per_sample_ms:.2f}",
        'peak_memory_mb': f"{peak_mem:.2f}",
        'peak_cpu_percent': f"{peak_cpu:.2f}",
        'chunk_size': str(config.chunk_size),
        'multithreading': t('perf_enabled') if config.use_multithreading else t('perf_disabled'),
        'algorithm_mode': t('perf_auto'),
    }


# =============================================================================
# 第九部分：矩阵验证器 / Part 9: Matrix Validator
# =============================================================================

class MMMValidator:
    """MMM矩阵合规性验证器 / MMM Matrix Compliance Validator"""

    def __init__(self, incomp_mat: np.ndarray, valid_mat: np.ndarray,
                 n_loci: int, sample_ids: List[str]):
        self.incomp_mat = incomp_mat
        self.valid_mat = valid_mat
        self.n_loci = n_loci
        self.sample_ids = sample_ids
        self.n_samples = len(sample_ids)

    def validate(self) -> Dict:
        """执行完整验证流程"""
        report = {
            'validation_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'tests': {},
            'overall_status': 'PENDING'
        }

        tests = [
            ('symmetry', t('validation_symmetry'), self._test_symmetry),
            ('nonnegative', t('validation_nonnegative'), self._test_nonnegative),
            ('bounded', t('validation_bounded'), self._test_bounded),
            ('integer', t('validation_integer'), self._test_integer),
            ('diagonal', t('validation_diagonal'), self._test_diagonal),
        ]

        passed = 0
        for test_id, test_name, test_func in tests:
            try:
                result = test_func()
                report['tests'][test_id] = {
                    'name': test_name,
                    'status': t('pass') if result else t('fail'),
                    'requirement': '-',
                }
                if result:
                    passed += 1
            except Exception as e:
                report['tests'][test_id] = {
                    'name': test_name,
                    'status': f"{t('error')}: {str(e)}",
                    'requirement': '-',
                }

        report['passed_count'] = passed
        report['test_count'] = len(tests)
        report['compliant'] = passed == len(tests)
        report['overall_status'] = t('all_passed') if report['compliant'] else t('partial_failed')

        return report

    def _test_symmetry(self) -> bool:
        m = np.nan_to_num(self.incomp_mat, nan=0)
        return np.allclose(m, m.T)

    def _test_nonnegative(self) -> bool:
        """非负性验证：所有非缺失值 ≥ 0"""
        valid = self.incomp_mat[~np.isnan(self.incomp_mat)]
        return len(valid) > 0 and np.all(valid >= 0)

    def _test_bounded(self) -> bool:
        """有界性验证：所有非缺失值 ≤ n_loci"""
        valid = self.incomp_mat[~np.isnan(self.incomp_mat)]
        return len(valid) > 0 and np.all(valid <= self.n_loci)

    def _test_integer(self) -> bool:
        """整数性验证：所有非缺失值为整数"""
        valid = self.incomp_mat[~np.isnan(self.incomp_mat)]
        return len(valid) > 0 and np.all(np.equal(np.mod(valid, 1), 0))

    def _test_diagonal(self) -> bool:
        """对角线规则验证：对角线元素为NaN"""
        return np.all(np.isnan(np.diag(self.incomp_mat)))



# =============================================================================
# 第十部分：Dk分级器 / Part 10: Dk Classifier
# =============================================================================

class DkClassifier:
    """MES分级计算器 / MES Grading Calculator"""

    def __init__(self, incomp_mat: np.ndarray, sample_ids: List[str]):
        self.incomp_mat = incomp_mat
        self.sample_ids = sample_ids
        self.n_samples = len(sample_ids)

    def classify(self) -> Dict:
        """执行Dk分级"""
        result = {
            'mmin': {},
            'mmax': {},
            'mmean': {},
            'mzmp': {},
            'dk': {},
            'dk_groups': {},
            'gk_groups': {},
            'gap_index': 0.0,
            'mzmp_partners': {}
        }

        for i, sid in enumerate(self.sample_ids):
            row = self.incomp_mat[i, :]
            valid_mask = ~np.isnan(row)

            if not np.any(valid_mask):
                continue

            valid_values = row[valid_mask]

            mmin = int(np.min(valid_values))
            result['mmin'][sid] = mmin

            mmax = int(np.max(valid_values))
            result['mmax'][sid] = mmax

            mmean = float(np.mean(valid_values))
            result['mmean'][sid] = mmean

            mzmp = int(np.sum(valid_values == 0))
            result['mzmp'][sid] = mzmp

            partners = [self.sample_ids[j] for j in range(self.n_samples)
                        if i != j and not np.isnan(row[j]) and row[j] == 0]
            result['mzmp_partners'][sid] = partners

            result['dk'][sid] = mmin

        max_k = max(result['mmin'].values()) if result['mmin'] else 0
        for k in range(max_k + 1):
            result['dk_groups'][k] = [
                sid for sid, v in result['mmin'].items() if v == k
            ]

        for k in range(max_k + 1):
            result['gk_groups'][k] = [
                sid for sid, v in result['mmin'].items() if v >= k
            ]

        empty_grades = sum(1 for k in range(max_k + 1)
                          if k not in result['dk_groups'] or len(result['dk_groups'][k]) == 0)
        result['gap_index'] = empty_grades / (max_k + 1) if max_k > 0 else 0

        return result



# =============================================================================
# 第十一部分：分级分析器 / Part 11: Grading Analyzer
# =============================================================================

class GradingAnalyzer:
    """
    矩阵分级分析核心类
    整合 MMM_Matrix_Grading.py 的核心功能
    """

    @staticmethod
    def validate_matrix(mmm_matrix_df: pd.DataFrame) -> None:
        """验证输入矩阵的格式和内容"""
        if mmm_matrix_df is None or mmm_matrix_df.empty:
            raise DataFormatError(t("error") + ": Input matrix is empty")

        if mmm_matrix_df.shape[0] < 2:
            raise DataFormatError(t("error") + ": Too few samples (need at least 2)")

        if mmm_matrix_df.shape[1] < 2:
            raise DataFormatError(t("error") + ": Too few columns (need ID + at least 1 sample column)")

        try:
            matrix_values = mmm_matrix_df.iloc[:, 1:].values
            matrix_values.astype(float)
        except (ValueError, TypeError) as e:
            raise DataFormatError(f"{t('error')}: Matrix data contains non-numeric values: {str(e)}")

    @staticmethod
    def analyze_from_matrix(M_matrix: np.ndarray, sample_list: List[str],
                            sample_id_col: str = 'SampleID') -> Dict:
        """
        基于错配矩阵（支持 np.ndarray / np.memmap）进行全面分析

        该方法避免一次性将整个矩阵加载为 float64，适用于超大规模数据集。
        """
        try:
            N = len(sample_list)
            if N < 2:
                raise DataFormatError(t("error") + ": Too few samples (need at least 2)")
            if M_matrix.shape != (N, N):
                raise DataFormatError(t("error") + f": Matrix shape {M_matrix.shape} does not match sample count {N}")

            # ===================== 基础指标计算（逐行，兼容 memmap） =====================
            mmin_list = np.empty(N, dtype=np.int32)
            mmax_list = np.empty(N, dtype=np.int32)
            mavg_list = np.empty(N, dtype=np.float64)
            mpc_list = np.empty(N, dtype=np.int32)
            partners_list = []

            for i in range(N):
                row = M_matrix[i, :].astype(np.float64)
                row[i] = np.nan
                valid_mask = ~np.isnan(row)
                if not np.any(valid_mask):
                    mmin_list[i] = 0
                    mmax_list[i] = 0
                    mavg_list[i] = 0.0
                    mpc_list[i] = 0
                    partners_list.append('')
                    continue
                valid_values = row[valid_mask]
                mmin_list[i] = int(np.min(valid_values))
                mmax_list[i] = int(np.max(valid_values))
                mavg_list[i] = round(np.mean(valid_values), 2)
                mpc_list[i] = int(np.sum(valid_values == 0))
                partners = [sample_list[j] for j in range(N)
                            if j != i and valid_mask[j] and row[j] == 0]
                partners_list.append(','.join(partners) if partners else '')

            basic_df = pd.DataFrame({
                sample_id_col: sample_list,
                COLUMN_MMIN: mmin_list,
                'Dk级别': mmin_list,
                COLUMN_MMAX: mmax_list,
                COLUMN_MAVG: mavg_list,
                COLUMN_MZMP: mpc_list,
                'Mzmp list.': partners_list,
            })

            # ===================== 零错配对 & 重复样本检测（分块扫描） =====================
            zero_pairs = []
            duplicate_pairs = []
            block_size = 1024

            for i_start in range(N - 1):
                i_end = min(i_start + 1, N)
                # 读取第 i_start 行的一个块：列范围 [i_start+1, N)
                # 为减少随机 I/O，按 block_size 分块读取列
                for j_start in range(i_start + 1, N, block_size):
                    j_end = min(j_start + block_size, N)
                    block = M_matrix[i_start:i_end, j_start:j_end].astype(np.float64)
                    if block.size == 0:
                        continue
                    local_j_idx = np.where(block[0, :] == 0)[0]
                    for jj in local_j_idx:
                        j = j_start + jj
                        if j <= i_start:
                            continue
                        # 判断是否为重复样本：比较两行（排除 i 和 j 列）
                        row_i = M_matrix[i_start, :].astype(np.float64)
                        row_j = M_matrix[j, :].astype(np.float64)
                        row_i[i_start] = np.nan
                        row_i[j] = np.nan
                        row_j[i_start] = np.nan
                        row_j[j] = np.nan
                        is_duplicate = np.allclose(row_i, row_j, atol=NAN_THRESHOLD, equal_nan=True)

                        mmmd_val = 1 if is_duplicate else 0
                        zero_pairs.append({
                            'SampleID_1': sample_list[i_start],
                            'SampleID_2': sample_list[j],
                            COLUMN_MMMD: mmmd_val
                        })
                        if is_duplicate:
                            duplicate_pairs.append({
                                'SampleID_1': sample_list[i_start],
                                'SampleID_2': sample_list[j],
                                COLUMN_MMMD: 1
                            })

            zero_pairs_df = pd.DataFrame(zero_pairs) if zero_pairs else pd.DataFrame(
                columns=['SampleID_1', 'SampleID_2', COLUMN_MMMD])
            duplicate_pairs_df = pd.DataFrame(duplicate_pairs) if duplicate_pairs else pd.DataFrame(
                columns=['SampleID_1', 'SampleID_2', COLUMN_MMMD])

            # ===================== 重复样本组 (并查集) =====================
            duplicate_groups, duplicate_sample_list = GradingAnalyzer._find_duplicate_groups(
                duplicate_pairs, sample_list
            )

            # ===================== 分级体系 =====================
            max_mmin = int(mmin_list.max())
            n = max_mmin

            G_dict = {}
            for k in range(0, n + 1):
                members = [sample_list[i] for i in range(N) if mmin_list[i] >= k]
                G_dict[k] = members

            D_dict = {}
            for k in range(0, n + 1):
                members = [sample_list[i] for i in range(N) if mmin_list[i] == k]
                D_dict[k] = members

            empty_D_count = sum(1 for k in range(0, n + 1) if len(D_dict[k]) == 0)
            mgi = empty_D_count / (n + 1) if (n + 1) > 0 else 0.0

            # 分级汇总表
            grading_summary = []
            for k in range(0, n + 1):
                grading_summary.append({
                    'Grade_k': k,
                    'C_k_Count': len(G_dict[k]),
                    'C_k_Percent': round(len(G_dict[k]) / N * 100, 2),
                    'C_k_Members': ';'.join(G_dict[k]),
                    'D_k_Count': len(D_dict[k]),
                    'D_k_Percent': round(len(D_dict[k]) / N * 100, 2),
                    'D_k_Members': ';'.join(D_dict[k]),
                    'D_k_Empty': 'Yes' if len(D_dict[k]) == 0 else 'No'
                })
            grading_summary_df = pd.DataFrame(grading_summary)

            return {
                'basic_df': basic_df,
                'grading_summary_df': grading_summary_df,
                'zero_pairs_df': zero_pairs_df,
                'duplicate_pairs_df': duplicate_pairs_df,
                'duplicate_groups': duplicate_groups,
                'duplicate_sample_list': duplicate_sample_list,
                'G_dict': G_dict,
                'D_dict': D_dict,
                'MGI': mgi,
                'max_mmin': n,
                'sample_list': sample_list,
                'mmin_list': mmin_list.tolist(),
                'M_matrix': M_matrix,
            }

        except DataFormatError:
            raise
        except Exception as e:
            raise AnalysisError(f"{t('error')}: Analysis execution failed: {str(e)}")

    @staticmethod
    def analyze(mmm_matrix_df: pd.DataFrame) -> Dict:
        """
        基于错配矩阵 DataFrame 进行全面分析

        内部转换为矩阵后调用 analyze_from_matrix。
        """
        try:
            GradingAnalyzer.validate_matrix(mmm_matrix_df)
            sample_id_col = mmm_matrix_df.columns[0]
            sample_list = mmm_matrix_df[sample_id_col].tolist()
            M_matrix = mmm_matrix_df.iloc[:, 1:].values.astype(np.float64)
            return GradingAnalyzer.analyze_from_matrix(M_matrix, sample_list, sample_id_col)
        except DataFormatError:
            raise
        except Exception as e:
            raise AnalysisError(f"{t('error')}: Analysis execution failed: {str(e)}")

    @staticmethod
    def _find_duplicate_groups(duplicate_pairs: list, sample_list: list) -> tuple:
        """使用并查集将重复样本对合并为重复样本组"""
        if not duplicate_pairs:
            return [], []

        sample_to_idx = {s: i for i, s in enumerate(sample_list)}
        n = len(sample_list)
        parent = list(range(n))

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(x, y):
            rx, ry = find(x), find(y)
            if rx != ry:
                parent[ry] = rx

        for pair in duplicate_pairs:
            i = sample_to_idx.get(pair['SampleID_1'])
            j = sample_to_idx.get(pair['SampleID_2'])
            if i is not None and j is not None:
                union(i, j)

        groups = {}
        for i in range(n):
            root = find(i)
            groups.setdefault(root, []).append(sample_list[i])

        duplicate_groups = [sorted(g) for g in groups.values() if len(g) > 1]
        duplicate_sample_list = sorted({s for g in duplicate_groups for s in g})

        return duplicate_groups, duplicate_sample_list


# =============================================================================
# 第十二部分：报告生成器 / Part 12: Report Generator
# =============================================================================

class ReportGenerator:
    """统一报告生成器 / Unified Report Generator"""

    def __init__(self, output_dir: str):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def save_matrices(self, results: MMMResults) -> None:
        """保存错配矩阵、有效位点矩阵、错配率矩阵及低错配对"""
        n = results.n_samples
        is_mmap = isinstance(results.incomp_mat, np.memmap)

        # 内存映射模式下，完整 N×N CSV 文件过大，跳过输出并提示用户
        if is_mmap:
            print(f"  ! {t('mmap_skip_matrix_csv')}")
            # 仍然尝试输出低错配品种对（通常数量可控）
        else:
            # 1. 错配矩阵 M
            incomp_df = pd.DataFrame(
                results.incomp_mat,
                index=results.sample_ids,
                columns=results.sample_ids
            )
            incomp_df.insert(0, 'SampleID', results.sample_ids)
            incomp_path = os.path.join(self.output_dir, OUTPUT_FILES['mmm_matrix'])
            incomp_df.to_csv(incomp_path, index=False, encoding='utf-8-sig', na_rep='NA')
            print(f"  ✓ {t('file_m_matrix')}: {incomp_path}")
            print(f"      {t('report_note')}: {t('desc_m_matrix')}")

            # 2. 有效位点矩阵 L
            valid_df = pd.DataFrame(
                results.valid_mat,
                index=results.sample_ids,
                columns=results.sample_ids
            )
            valid_df.insert(0, 'SampleID', results.sample_ids)
            valid_path = os.path.join(self.output_dir, OUTPUT_FILES['valid_matrix'])
            valid_df.to_csv(valid_path, index=False, encoding='utf-8-sig', na_rep='NA')
            print(f"  ✓ {t('file_l_matrix')}: {valid_path}")
            print(f"      {t('report_note')}: {t('desc_l_matrix')}")

            # 3. 错配率矩阵 M/L
            with np.errstate(divide='ignore', invalid='ignore'):
                rate_mat = np.where(results.valid_mat > 0, results.incomp_mat / results.valid_mat, np.nan)
            np.fill_diagonal(rate_mat, np.nan)
            rate_df = pd.DataFrame(
                rate_mat,
                index=results.sample_ids,
                columns=results.sample_ids
            )
            rate_df.insert(0, 'SampleID', results.sample_ids)
            rate_path = os.path.join(self.output_dir, OUTPUT_FILES['mismatch_rate_matrix'])
            rate_df.to_csv(rate_path, index=False, encoding='utf-8-sig', na_rep='NA', float_format='%.3f')
            print(f"  ✓ {t('file_rate_matrix')}: {rate_path}")
            print(f"      {t('report_note')}: {t('desc_rate_matrix')}")

        # 4. 低错配品种对 (M=0~2)
        mnp_data = []
        n = results.n_samples
        for i in range(n):
            for j in range(i + 1, n):
                m_val = results.incomp_mat[i, j]
                if not np.isnan(m_val) and 0 <= int(m_val) <= 2:
                    mnp_data.append({
                        'SampleID_1': results.sample_ids[i],
                        'SampleID_2': results.sample_ids[j],
                        'Mmn': int(m_val)
                    })
        mnp_df = pd.DataFrame(mnp_data, columns=['SampleID_1', 'SampleID_2', 'Mmn'])
        mnp_path = os.path.join(self.output_dir, OUTPUT_FILES['mnp_pairs'])
        mnp_df.to_csv(mnp_path, index=False, encoding='utf-8-sig')
        print(f"  ✓ {t('file_mnp')}: {mnp_path}")
        print(f"      {t('report_note')}: {t('desc_mnp', len(mnp_df))}")

    def save_frequency(self, results: MMMResults, grading: Dict) -> None:
        """生成频率分布文件：包括 Mmn(成对错配)、Mmin、Mzmp、Mavg(0.5 步长) 的频率和百分比"""
        from collections import Counter
        M = results.incomp_mat
        n = results.n_samples
        rows_by_metric = {}

        # 1) Mmn: pairwise mismatch distribution
        pair_vals = []
        for i in range(n):
            for j in range(i + 1, n):
                v = M[i, j]
                if not np.isnan(v):
                    pair_vals.append(int(v))
        total_pairs = len(pair_vals)
        cnt = Counter(pair_vals)
        mmn_list = []
        for val in sorted(cnt.keys()):
            freq = cnt[val]
            mmn_list.append((val, freq))
        rows_by_metric['Mmn'] = (mmn_list, total_pairs)

        # 2) Mmin: per-sample minimal mismatch
        mmin_list = grading.get('mmin_list', grading.get('mmin_list', []))
        total_samples = len(mmin_list)
        cnt_mmin = Counter(mmin_list)
        mmin_list_rows = [(val, cnt_mmin[val]) for val in sorted(cnt_mmin.keys())]
        rows_by_metric['Mmin'] = (mmin_list_rows, total_samples)

        # 3) Mzmp: zero-mismatch partners count per sample
        basic_df = grading.get('basic_df')
        if basic_df is not None and COLUMN_MZMP in basic_df.columns:
            mzmp_series = basic_df[COLUMN_MZMP].fillna(0).astype(int)
            cnt_mzmp = Counter(mzmp_series.tolist())
            mzmp_rows = [(val, cnt_mzmp[val]) for val in sorted(cnt_mzmp.keys())]
        else:
            mzmp_rows = []
        rows_by_metric['Mzmp'] = (mzmp_rows, total_samples)

        # 4) Mavg: average mismatch per sample, binned by 0.5
        mavg_rows = []
        if basic_df is not None and COLUMN_MAVG in basic_df.columns:
            mavg_series = basic_df[COLUMN_MAVG].dropna().astype(float)
            if not mavg_series.empty:
                lo = float(np.floor(mavg_series.min()))
                hi = float(np.ceil(mavg_series.max()))
                bins = np.arange(lo, hi + 0.5, 0.5)
                if len(bins) < 2:
                    bins = np.array([lo, lo + 0.5])
                labels = [f"{bins[i]}-{bins[i+1]}" for i in range(len(bins) - 1)]
                binned = pd.cut(mavg_series, bins=bins, labels=labels, include_lowest=True)
                cnt_mavg = Counter(binned.astype(str).tolist())
                mavg_rows = [(label, int(cnt_mavg.get(label, 0))) for label in labels]
        rows_by_metric['Mavg'] = (mavg_rows, total_samples)

        # Build final rows with cumulative and percentage per metric
        final_rows = []
        for metric, (lst, total) in rows_by_metric.items():
            cum = 0
            for val, freq in lst:
                cum += freq
                pct = round(freq / total * 100, 2) if total > 0 else 0.0
                final_rows.append({
                    'Metric': metric,
                    'Value': val,
                    'Frequency': freq,
                    'Cumulative': cum,
                    'Percentage': f"{pct:.2f}%"
                })

        freq_df = pd.DataFrame(final_rows, columns=['Metric', 'Value', 'Frequency', 'Cumulative', 'Percentage'])
        freq_path = os.path.join(self.output_dir, OUTPUT_FILES['frequency'])
        freq_df.to_csv(freq_path, index=False, encoding='utf-8-sig')
        print(f"  ✓ {t('file_frequency') if 'file_frequency' in I18n._dict else 'Frequency'}: {freq_path}")

    def save_zero_mismatch_pairs(self, zero_pairs_df: pd.DataFrame) -> None:
        """保存零错配对及Mmmd结果"""
        path = os.path.join(self.output_dir, OUTPUT_FILES['zero_pairs'])
        zero_pairs_df.to_csv(path, index=False, encoding='utf-8-sig')
        print(f"  ✓ {t('file_zero_pairs')}: {path}")
        print(f"      {t('report_note')}: {t('desc_zero_pairs')}")
        if not zero_pairs_df.empty:
            dup_count = int((zero_pairs_df['Mmmd'] == 1).sum())
            print(f"      {t('stats_zero_dup', len(zero_pairs_df), dup_count)}")

    def save_grading_results(self, grading: Dict) -> None:
        """保存分级分析结果"""
        # MMM_basic.csv
        basic_path = os.path.join(self.output_dir, OUTPUT_FILES['basic'])
        grading['basic_df'].to_csv(basic_path, index=False, encoding='utf-8-sig')
        print(f"  ✓ {t('file_basic')}: {basic_path}")
        print(f"      {t('report_note')}: {t('desc_basic')}")

        # MMM_Grading_Summary.csv
        summary_path = os.path.join(self.output_dir, OUTPUT_FILES['grading_summary'])
        grading['grading_summary_df'].to_csv(summary_path, index=False, encoding='utf-8-sig')
        print(f"  ✓ {t('file_grading_summary')}: {summary_path}")
        print(f"      {t('report_note')}: {t('desc_grading_summary')}")

        # MMM_MGI.txt（输出文件内容保持固定英文格式，与手册示例一致）
        mgi_path = os.path.join(self.output_dir, OUTPUT_FILES['mgi'])
        with open(mgi_path, 'w', encoding='utf-8') as f:
            f.write(f"MGI (Matrix Gap Index) = {grading['MGI']:.4f}\n")
            f.write(f"Max Mmin = {grading['max_mmin']}\n")
            f.write(f"Total Samples = {len(grading['sample_list'])}\n")
        print(f"  ✓ {t('file_mgi')}: {mgi_path}")
        print(f"      {t('report_note')}: {t('desc_mgi')}")
        print(f"      MGI (Matrix Gap Index) = {grading['MGI']:.4f}, Max Mmin = {grading['max_mmin']}, Total Samples = {len(grading['sample_list'])}")

        # MMM_Zero_Mismatch_Pairs.csv
        zp_path = os.path.join(self.output_dir, OUTPUT_FILES['zero_pairs'])
        grading['zero_pairs_df'].to_csv(zp_path, index=False, encoding='utf-8-sig')
        print(f"  ✓ {t('file_zero_pairs')}: {zp_path}")
        print(f"      {t('report_note')}: {t('desc_zero_pairs')}")

        # MMM_Duplicate_Samples.csv
        if not grading['duplicate_pairs_df'].empty:
            dup_path = os.path.join(self.output_dir, OUTPUT_FILES['duplicate_samples'])
            grading['duplicate_pairs_df'].to_csv(dup_path, index=False, encoding='utf-8-sig')
            print(f"  ✓ {t('file_dup_pairs')}: {dup_path}")
            print(f"      {t('report_note')}: {t('desc_dup_pairs')}")
        else:
            print(f"  ✓ {t('file_dup_pairs')}: {t('no_dup_detected')}")

        # MMM_Duplicate_Groups.csv
        if grading['duplicate_groups']:
            groups_data = []
            for idx, group in enumerate(grading['duplicate_groups'], 1):
                groups_data.append({
                    'Group_ID': idx,
                    'Group_Size': len(group),
                    'Members': ';'.join(group)
                })
            dg_path = os.path.join(self.output_dir, OUTPUT_FILES['duplicate_groups'])
            pd.DataFrame(groups_data).to_csv(dg_path, index=False, encoding='utf-8-sig')
            print(f"  ✓ {t('file_dup_groups')}: {dg_path}")
            print(f"      {t('report_note')}: {t('desc_dup_groups')}")
        else:
            print(f"  ✓ {t('file_dup_groups')}: {t('no_dup_groups')}")

    def generate_analytical_report(self, results: MMMResults,
                                    validation_report: Dict,
                                    total_time: float,
                                    config: 'MMMConfig') -> pd.DataFrame:
        """生成完整分析报告"""
        rows = []
        n, n_loci = results.n_samples, results.n_loci
        sys_info = get_system_info()
        perf = get_performance_metrics(results, total_time, config)

        rows.extend([
            [t('category_basic'), t('metric_total_samples'), str(n), '≥1', t('pass') if n >= 1 else t('sample_insufficient')],
            [t('category_basic'), t('metric_total_loci'), str(n_loci), '≥5', t('pass') if n_loci >= 5 else t('marker_insufficient')],
            [t('category_basic'), t('metric_marker_type'), results.marker_type, 'SSR/SNP', t('recognized')],
            [t('category_basic'), t('metric_total_time'), f"{total_time:.2f}", '-', t('done')],
        ])

        rows.extend([
            [t('category_system'), t('system_os'), sys_info['os'], '-', '-'],
            [t('category_system'), t('system_cpu_model'), sys_info['cpu_model'], '-', '-'],
            [t('category_system'), t('system_cpu_frequency'), f"{sys_info['cpu_frequency_mhz']} MHz", '-', '-'],
            [t('category_system'), t('system_physical_cores'), sys_info['physical_cores'], '-', '-'],
            [t('category_system'), t('system_logical_cores'), sys_info['logical_cores'], '-', '-'],
            [t('category_system'), t('system_total_memory'), f"{sys_info['total_memory_gb']} GB", '-', '-'],
            [t('category_system'), t('system_available_memory'), f"{sys_info['available_memory_gb']} GB", '-', '-'],
            [t('category_system'), t('system_python_version'), sys_info['python_version'], '-', '-'],
        ])

        rows.extend([
            [t('category_system'), t('lib_numpy_version'), sys_info['numpy_version'], '-', '-'],
            [t('category_system'), t('lib_pandas_version'), sys_info['pandas_version'], '-', '-'],
            [t('category_system'), t('lib_psutil_version'), sys_info['psutil_version'], '-', '-'],
        ])

        rows.extend([
            [t('category_algorithm'), t('metric_core_algorithm'), t('vec_parallel_compute'), '-', t('mmm_compliant')],
            [t('category_algorithm'), t('metric_time_complexity'), 'O(N²)', '-', t('optimized')],
        ])

        rows.extend([
            [t('category_performance'), t('perf_dataset_size'), perf['dataset_size'], '-', '-'],
            [t('category_performance'), t('perf_total_pairs'), perf['total_pairs'], '-', '-'],
            [t('category_performance'), t('perf_total_runtime'), perf['total_runtime_s'], '-', '-'],
            [t('category_performance'), t('perf_throughput_pairs_sec'), perf['throughput_pairs_sec'], '-', '-'],
            [t('category_performance'), t('perf_time_per_pair_us'), perf['time_per_pair_us'], '-', '-'],
            [t('category_performance'), t('perf_time_per_sample_ms'), perf['time_per_sample_ms'], '-', '-'],
            [t('category_performance'), t('perf_peak_memory_mb'), perf['peak_memory_mb'], '-', '-'],
            [t('category_performance'), t('perf_peak_cpu_percent'), perf['peak_cpu_percent'], '-', '-'],
            [t('category_performance'), t('perf_chunk_size'), perf['chunk_size'], '-', '-'],
            [t('category_performance'), t('perf_multithreading'), perf['multithreading'], '-', '-'],
            [t('category_performance'), t('perf_algorithm_mode'), perf['algorithm_mode'], '-', '-'],
        ])

        for test_name, test_info in validation_report['tests'].items():
            rows.append([
                t('category_validation'),
                test_info['name'],
                test_info['status'],
                test_info['requirement'],
                test_info['status']
            ])

        rows.append([
            t('category_validation'),
            t('final_conclusion'),
            validation_report['overall_status'],
            t('all_passed'),
            validation_report['overall_status']
        ])

        if results.grading_result:
            grading = results.grading_result
            rows.append([t('category_grading'), t('metric_mgi'), f"{grading['MGI']:.4f}", '-', '-'])
            rows.append([t('category_grading'), t('metric_max_mmin'), str(grading['max_mmin']), '-', '-'])
            rows.append([t('category_grading'), t('metric_zero_pairs'), str(len(grading['zero_pairs_df'])), '-', '-'])
            rows.append([t('category_grading'), t('metric_dup_pairs'), str(len(grading['duplicate_pairs_df'])), '-', '-'])
            rows.append([t('category_grading'), t('metric_dup_groups'), str(len(grading['duplicate_groups'])), '-', '-'])

        report_df = pd.DataFrame(rows, columns=[t('category'), t('metric'), t('value'), t('standard'), t('conclusion')])
        report_path = os.path.join(self.output_dir, OUTPUT_FILES['report'])
        report_df.to_csv(report_path, index=False, encoding='utf-8-sig')
        print(f"  ✓ {t('file_report')}: {report_path}")
        print(f"      {t('report_note')}: {t('desc_report')}")

        return report_df

    def generate_summary_txt(self, results: MMMResults, validation_report: Dict,
                             total_time: float,
                             config: 'MMMConfig') -> str:
        """生成摘要文本报告"""
        sys_info = get_system_info()
        perf = get_performance_metrics(results, total_time, config)
        lines = [
            "=" * 80,
            "          " + t("report_title"),
            "=" * 80,
            "",
            f"{t('report_analysis_time')}: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"{t('report_marker_type')}: {results.marker_type}",
            f"{t('report_sample_count')}: {results.n_samples}",
            f"{t('report_locus_count')}: {results.n_loci}",
            f"{t('total_time_label')}: {total_time:.2f}{t('seconds')}",
            "",
            "=" * 80,
            t("system_info_header") + ":",
            "=" * 80,
            f"  {t('system_os')}: {sys_info['os']}",
            f"  {t('system_cpu_model')}: {sys_info['cpu_model']}",
            f"  {t('system_cpu_frequency')}: {sys_info['cpu_frequency_mhz']} MHz",
            f"  {t('system_physical_cores')}: {sys_info['physical_cores']}",
            f"  {t('system_logical_cores')}: {sys_info['logical_cores']}",
            f"  {t('system_total_memory')}: {sys_info['total_memory_gb']} GB",
            f"  {t('system_available_memory')}: {sys_info['available_memory_gb']} GB",
            f"  {t('system_python_version')}: {sys_info['python_version']}",
            "",
            "=" * 80,
            t("software_env_header") + ":",
            "=" * 80,
            f"  {t('lib_numpy_version')}: {sys_info['numpy_version']}",
            f"  {t('lib_pandas_version')}: {sys_info['pandas_version']}",
            f"  {t('lib_psutil_version')}: {sys_info['psutil_version']}",
            "",
            "=" * 80,
            t("performance_header") + ":",
            "=" * 80,
            f"  {t('perf_dataset_size')}: {perf['dataset_size']}",
            f"  {t('perf_total_pairs')}: {perf['total_pairs']}",
            f"  {t('perf_total_runtime')}: {perf['total_runtime_s']}",
            f"  {t('perf_throughput_pairs_sec')}: {perf['throughput_pairs_sec']}",
            f"  {t('perf_time_per_pair_us')}: {perf['time_per_pair_us']}",
            f"  {t('perf_time_per_sample_ms')}: {perf['time_per_sample_ms']}",
            f"  {t('perf_peak_memory_mb')}: {perf['peak_memory_mb']}",
            f"  {t('perf_peak_cpu_percent')}: {perf['peak_cpu_percent']}",
            f"  {t('perf_chunk_size')}: {perf['chunk_size']}",
            f"  {t('perf_multithreading')}: {perf['multithreading']}",
            f"  {t('perf_algorithm_mode')}: {perf['algorithm_mode']}",
            "",
            "-" * 80,
            "[" + t("report_validation") + "]",
            "-" * 80,
        ]

        for test_name, test_info in validation_report['tests'].items():
            icon = "✓" if test_info['status'] == t('pass') else "✗"
            lines.append(f"  {icon} {test_info['name']}: {test_info['status']}")

        lines.extend([
            "",
            f"  {t('report_final_conclusion')}: {validation_report['overall_status']}",
            "",
            "=" * 80,
            t("report_output_files") + ":",
            "=" * 80,
        ])

        # 分级分析相关文件仅在 grading_result 存在时输出
        grading_dependent = {'basic', 'grading_summary', 'mgi', 'duplicate_samples',
                             'duplicate_groups', 'only_data', 'frequency'}
        has_grading = bool(results.grading_result)

        for key, filename in OUTPUT_FILES.items():
            if key in grading_dependent and not has_grading:
                continue
            lines.append(f"  • {filename}")

        file_desc_lines = [
            "",
            "[" + t("report_file_desc") + "]",
            "  • MMM_Matrix.csv           - " + t("sum_m_matrix"),
            "  • MMM_Effective_Loci_Matrix.csv - " + t("sum_l_matrix"),
            "  • MMM_Mmr_Matrix.csv       - " + t("sum_rate_matrix"),
            "  • MMM_Mnp_Mismatch_Pairs.csv - " + t("sum_mnp"),
            "  • MMM_Analytical_Report.csv - " + t("sum_report"),
            "  • MMM_Build_Report.txt     - " + t("sum_summary"),
        ]
        if has_grading:
            file_desc_lines.extend([
                "  • MMM_basic.csv            - " + t("sum_basic"),
                "  • MMM_Grading_Summary.csv  - " + t("sum_grading"),
                "  • MMM_MGI.txt              - " + t("sum_mgi"),
            ])
        file_desc_lines.extend([
            "  • MMM_Zero_Mismatch_Pairs.csv - " + t("sum_zero_pairs"),
        ])
        if has_grading:
            file_desc_lines.extend([
                "  • MMM_Duplicate_Samples.csv - " + t("sum_dup_samples"),
                "  • MMM_Duplicate_Groups.csv - " + t("sum_dup_groups"),
                "  • MMM_only_data.csv        - " + t("sum_only_data"),
                "  • MMM_frequency.csv        - " + t("sum_frequency"),
            ])

        lines.extend(file_desc_lines)

        # === 各阶段耗时与资源占用汇总 ===
        phase_timings = results.timestamps.get('phase_timings', {})
        phase_resources = results.timestamps.get('phase_resources', {})

        lines.extend([
            "",
            "=" * 80,
            t("phase_resource_header") + ":",
            "=" * 80,
        ])

        header = f"  {t('phase_col_phase'):<46} {t('phase_col_time'):>12} {t('phase_col_memory'):>16} {t('phase_col_cpu'):>12}"
        lines.append(header)
        lines.append("  " + "-" * 78)

        for phase_key in phase_timings:
            phase_label = t(phase_key) if phase_key.startswith('phase') else phase_key
            elapsed = phase_timings.get(phase_key, 0.0)
            res = phase_resources.get(phase_key, {})
            max_mem = res.get('max_memory_mb', 0.0) if res else 0.0
            max_cpu = res.get('max_cpu_percent', 0.0) if res else 0.0
            mem_str = f"{max_mem:.2f}" if max_mem else t('phase_na')
            cpu_str = f"{max_cpu:.2f}" if max_cpu else t('phase_na')
            lines.append(
                f"  {phase_label:<46} {elapsed:>12.2f} {mem_str:>16} {cpu_str:>12}"
            )

        lines.extend([
            "  " + "-" * 78,
            f"  {t('total_time_label')}: {total_time:.2f}{t('seconds')}",
        ])

        lines.append("=" * 80)

        summary = "\n".join(lines)
        summary_path = os.path.join(self.output_dir, OUTPUT_FILES['summary'])
        with open(summary_path, 'w', encoding='utf-8') as f:
            f.write(summary)
        print(f"  ✓ {t('file_summary')}: {summary_path}")

        return summary



# =============================================================================
# 第十三部分：统一工作流 / Part 13: Unified Workflow
# =============================================================================

class MMMWorkflow:
    """MMM 统一工作流 / MMM Unified Workflow: Matrix Build (with auto grading output)"""

    def __init__(self, config: MMMConfig):
        self.config = config
        self.df = None
        self.structure = None
        self.marker_type = None
        self.geno_array = None
        self.missing_mask = None

    def run(self) -> MMMResults:
        """执行完整工作流"""
        start_time = time.time()
        timings: Dict[str, float] = {}
        resources: Dict[str, Dict[str, float]] = {}

        # ========== Phase 1: 数据加载 ==========
        print("\n" + t("phase1"))
        with phase_profiler(timings, resources, 'phase1_timing'):
            self._load_data()
        print(f"  {t('time_cost')}: {timings['phase1_timing']:.2f}{t('seconds')}")

        # ========== Phase 2: 构建基因型数组 ==========
        print("\n" + t("phase2"))
        with phase_profiler(timings, resources, 'phase2_timing'):
            self.geno_array, self.missing_mask = GenotypeProcessor.build_geno_array(
                self.df, self.structure, self.marker_type
            )
        print(f"  ✓ {t('genotype_matrix')}: {self.structure['n_samples']}×{self.structure['n_loci']}×2")
        print(f"  {t('time_cost')}: {timings['phase2_timing']:.2f}{t('seconds')}")

        # ========== Phase 3: 计算错配矩阵 ==========
        print("\n" + t("phase3"))
        with phase_profiler(timings, resources, 'phase3_timing'):
            incomp_mat, valid_mat = self._calculate_mismatch()
        print(f"  {t('time_cost')}: {timings['phase3_timing']:.2f}{t('seconds')}")

        # ========== Phase 4: 数学验证 ==========
        print("\n" + t("phase4"))
        with phase_profiler(timings, resources, 'phase4_timing'):
            validator = MMMValidator(incomp_mat, valid_mat, self.structure['n_loci'], self.structure['sample_ids'])
            validation_report = validator.validate()

        for test_name, test_info in validation_report['tests'].items():
            icon = "✓" if test_info['status'] == t('pass') else "✗"
            print(f"  {icon} {test_info['name']}: {test_info['status']}")
        print(f"\n  {t('final_conclusion')}: {validation_report['overall_status']}")
        print(f"  {t('time_cost')}: {timings['phase4_timing']:.2f}{t('seconds')}")

        # ========== Phase 5: Dk分级 ==========
        print("\n" + t("phase5"))
        with phase_profiler(timings, resources, 'phase5_timing'):
            classifier = DkClassifier(incomp_mat, self.structure['sample_ids'])
            dk_results = classifier.classify()
        print(f"  ✓ {t('mmin_range')}: 0-{max(dk_results['mmin'].values()) if dk_results['mmin'] else 0}")
        print(f"  ✓ {t('gap_index')}: {dk_results['gap_index']:.3f}")
        print(f"  {t('time_cost')}: {timings['phase5_timing']:.2f}{t('seconds')}")

        # ========== Phase 5b: 零错配对 ==========
        print("\n" + t("phase5b"))
        with phase_profiler(timings, resources, 'phase5b_timing'):
            zero_pairs_df = self._find_zero_mismatch_pairs(incomp_mat)
        print(f"  ✓ {t('zero_pairs')}: {len(zero_pairs_df)}")
        if not zero_pairs_df.empty:
            dup_count = int((zero_pairs_df['Mmmd'] == 1).sum())
            print(f"  ✓ {t('dup_pairs')}: {dup_count}")
            if dup_count > 0:
                # 生成去重后的基因型数据文件
                dup_pairs_list = zero_pairs_df[zero_pairs_df['Mmmd'] == 1].to_dict('records')
                dup_groups, _ = GradingAnalyzer._find_duplicate_groups(
                    dup_pairs_list, self.structure['sample_ids']
                )
                if dup_groups:
                    self._save_deduplicated_data(dup_groups)
        print(f"  {t('time_cost')}: {timings['phase5b_timing']:.2f}{t('seconds')}")

        # ========== Phase 6: 分级分析（可选） ==========
        grading_result = {}
        if self.config.auto_grading:
            print("\n" + t("phase6"))
            with phase_profiler(timings, resources, 'phase6_timing'):
                grading_result = GradingAnalyzer.analyze_from_matrix(
                    incomp_mat, self.structure['sample_ids'], sample_id_col='SampleID'
                )
            print(f"  ✓ {t('grading_system')}: 0-{grading_result['max_mmin']}{t('grading_levels')}")
            print(f"  ✓ MGI: {grading_result['MGI']:.4f}")
            print(f"  ✓ {t('dup_groups')}: {len(grading_result['duplicate_groups'])}")
            print(f"  {t('time_cost')}: {timings['phase6_timing']:.2f}{t('seconds')}")

        # 组装结果对象（供报告生成使用；phase7 的资源信息将在该阶段结束后追加）
        results = MMMResults(
            incomp_mat=incomp_mat,
            valid_mat=valid_mat,
            sample_ids=self.structure['sample_ids'],
            locus_names=self.structure['locus_names'],
            marker_type=self.marker_type,
            n_samples=self.structure['n_samples'],
            n_loci=self.structure['n_loci'],
            dk_classification=dk_results,
            validation_report=validation_report,
            grading_result=grading_result,
            zero_mismatch_pairs=zero_pairs_df,
            timestamps={
                'analysis_start': datetime.fromtimestamp(start_time).isoformat(),
                'phase_timings': {k: round(v, 3) for k, v in timings.items()},
                'phase_resources': {k: v for k, v in resources.items()},
            }
        )

        # phase7 开始前的累计耗时（用于内部 analytical report 的总耗时字段）
        report_total_time = time.time() - start_time

        # ========== Phase 7: 生成报告 ==========
        print("\n" + t("phase7"))
        with phase_profiler(timings, resources, 'phase7_timing'):
            generator = ReportGenerator(self.config.output_dir)
            generator.save_matrices(results)
            generator.save_zero_mismatch_pairs(zero_pairs_df)
            if grading_result:
                generator.save_grading_results(grading_result)
                # additionally output frequency distributions
                generator.save_frequency(results, grading_result)
            generator.generate_analytical_report(results, validation_report, report_total_time, self.config)
        print(f"  {t('time_cost')}: {timings['phase7_timing']:.2f}{t('seconds')}")

        end_time = time.time()
        total_time = end_time - start_time

        # 追加 phase7 的耗时与资源信息
        results.timestamps['analysis_end'] = datetime.fromtimestamp(end_time).isoformat()
        results.timestamps['total_seconds'] = round(total_time, 3)
        results.timestamps['phase_timings'] = {k: round(v, 3) for k, v in timings.items()}
        results.timestamps['phase_resources'] = {k: v for k, v in resources.items()}

        # 生成摘要文本报告
        generator.generate_summary_txt(results, validation_report, total_time, self.config)

        print("\n" + "=" * 80)
        print(t("phase_timing_header") + ":")
        for phase_name, seconds in timings.items():
            res = resources.get(phase_name, {})
            mem_info = f"{res.get('max_memory_mb', 0.0):.1f}MB" if res else "N/A"
            cpu_info = f"{res.get('max_cpu_percent', 0.0):.1f}%" if res else "N/A"
            print(f"  {t(phase_name)}: {seconds:.2f}{t('seconds')}  [Mem {mem_info}, CPU {cpu_info}]")
        print(f"{'-'*40}")
        print(f"{t('total_time_label')}: {total_time:.2f}{t('seconds')}")
        print(f"{t('output_dir_label')}: {self.config.output_dir}")
        print("=" * 80)

        return results

    def _load_data(self):
        """加载数据"""
        encodings = ['utf-8', 'utf-8-sig', 'gbk', 'gb2312', 'latin-1']
        read_success = False
        last_error = None

        for encoding in encodings:
            try:
                self.df = pd.read_csv(self.config.input_file, low_memory=False, dtype=str, encoding=encoding)
                print(f"  ✓ File Encoding: {encoding}")
                read_success = True
                break
            except Exception as e:
                last_error = e
                continue

        if not read_success:
            raise ValueError(f"{t('error')}: Unable to read file, please ensure it is a valid CSV. Last error: {last_error}")

        raw_format_type = DataStructureDetector.detect_format(self.df)
        if raw_format_type == 'unknown':
            raise ValueError(t("error") + ": Unable to auto-detect data format, please check file format")

        # 格式C（SSR原始双表头格式）预处理为分列格式
        format_type = raw_format_type
        if format_type == 'format_c':
            self.df = DataStructureDetector.preprocess_format_c(self.df)
            format_type = 'reformatted'

        # 用户友好的格式名称映射
        format_display_map = {
            'original': t('fmt_original'),
            'reformatted': t('fmt_reformatted'),
            'snp': t('fmt_snp'),
            'transposed_base_snp': t('fmt_transposed_snp'),
            'format_c': t('fmt_format_c'),
        }
        print(f"  ✓ {t('fmt_detected')}: {format_display_map.get(raw_format_type, raw_format_type)}")

        self.structure = DataStructureDetector.detect_structure(self.df, format_type)
        print(f"  ✓ {t('sample_count')}: {self.structure['n_samples']}")
        print(f"  ✓ {t('locus_count')}: {self.structure['n_loci']}")

        if self.config.marker_type:
            self.marker_type = self.config.marker_type
            print(f"  ✓ {t('marker_type_user')}: {self.marker_type}")
        else:
            self.marker_type = MarkerTypeDetector.detect(self.df, self.structure)
            print(f"  ✓ {t('marker_type_auto')}: {self.marker_type}")

    def _calculate_mismatch(self) -> Tuple[np.ndarray, np.ndarray]:
        """计算错配矩阵

        当样本数很大、完整 N×N 矩阵可能超出可用内存时，
        自动使用 np.memmap 将矩阵存放在磁盘上，避免内存分配失败。
        """
        n = self.structure['n_samples']
        use_mmap = _requires_mmap(n, n_matrices=2, dtype=np.float32, safety_factor=0.5)

        if use_mmap:
            print(f"  {t('mmap_mode_notice')}")
            mmap_dir = os.path.join(self.config.output_dir, '.mmap')
            os.makedirs(mmap_dir, exist_ok=True)
            incomp_path = os.path.join(mmap_dir, 'incomp_mat.mmap')
            valid_path = os.path.join(mmap_dir, 'valid_mat.mmap')
            incomp_mat = create_mmap_matrix(incomp_path, (n, n), np.float32, fill_value=np.nan)
            valid_mat = create_mmap_matrix(valid_path, (n, n), np.float32, fill_value=np.nan)
        else:
            incomp_mat = np.full((n, n), np.nan, dtype=np.float32)
            valid_mat = np.full((n, n), np.nan, dtype=np.float32)

        if n <= 100:
            calculator = MismatchCalculator(self.geno_array, self.missing_mask)
            temp_incomp, temp_valid = calculator.calculate_standard()
            incomp_mat[:] = temp_incomp.astype(np.float32)
            valid_mat[:] = temp_valid.astype(np.float32)
        elif n <= 1000:
            calculator = MismatchCalculator(self.geno_array, self.missing_mask)
            temp_incomp, temp_valid = calculator.calculate_vectorized()
            incomp_mat[:] = temp_incomp.astype(np.float32)
            valid_mat[:] = temp_valid.astype(np.float32)
        else:
            calc = ParallelMMMCalculator(
                checkpoint_dir=self.config.output_dir if self.config.enable_checkpoint else None
            )
            incomp_mat, valid_mat = calc.calculate(
                self.geno_array, self.missing_mask,
                use_multithreading=self.config.use_multithreading,
                chunk_size=self.config.chunk_size,
                M_matrix=incomp_mat,
                Lij_matrix=valid_mat
            )

        np.fill_diagonal(incomp_mat, np.nan)
        np.fill_diagonal(valid_mat, np.nan)

        total_pairs = n * (n - 1) // 2
        print(f"  ✓ {t('pairs_calculated')}: {total_pairs}")

        return incomp_mat, valid_mat

    def _find_zero_mismatch_pairs(self, incomp_mat: np.ndarray) -> pd.DataFrame:
        """检测零错配对及Mmmd"""
        sample_ids = self.structure['sample_ids']
        n = len(sample_ids)
        zero_pairs = []

        zero_mask = (incomp_mat == 0)
        np.fill_diagonal(zero_mask, False)
        i_idx, j_idx = np.where(np.triu(zero_mask, k=1))

        for i, j in zip(i_idx, j_idx):
            mask = np.ones(n, dtype=bool)
            mask[i] = False
            mask[j] = False

            row_i = incomp_mat[i, mask]
            row_j = incomp_mat[j, mask]
            is_duplicate = np.allclose(row_i, row_j, atol=NAN_THRESHOLD)

            mmmd_val = 1 if is_duplicate else 0
            zero_pairs.append({
                'SampleID_1': sample_ids[i],
                'SampleID_2': sample_ids[j],
                'Mmmd': mmmd_val
            })

        df = pd.DataFrame(zero_pairs) if zero_pairs else pd.DataFrame(
            columns=['SampleID_1', 'SampleID_2', 'Mmmd'])
        return df

    def _save_deduplicated_data(self, duplicate_groups: list) -> None:
        """生成去重后的基因型数据文件，每个重复组只保留第一个样本"""
        # 确定要删除的样本（每个重复组除第一个外的所有样本）
        samples_to_remove = set()
        for group in duplicate_groups:
            samples_to_remove.update(group[1:])

        # 根据格式类型选择删除行或列
        if self.structure and self.structure.get('format_type') == 'transposed_base_snp':
            # transposed_base_snp: 样本是列，删除对应列
            cols_to_remove = [c for c in self.df.columns[1:] if c in samples_to_remove]
            dedup_df = self.df.drop(columns=cols_to_remove).copy()
        else:
            # 其他格式: 样本是行，删除对应行
            sample_col = self.df.columns[0]
            dedup_df = self.df[~self.df[sample_col].astype(str).isin(samples_to_remove)].copy()

        # 保存去重后的数据
        output_path = os.path.join(self.config.output_dir, OUTPUT_FILES['only_data'])
        dedup_df.to_csv(output_path, index=False, encoding='utf-8-sig')
        print(f"  ✓ {t('file_only_data')}: {output_path}")
        print(f"      {t('report_note')}: {t('desc_only_data')}")
        print(f"      {t('original_count')}: {len(self.df)}, {t('dedup_count')}: {len(dedup_df)}, {t('removed_count')}: {len(samples_to_remove)}")
        print(f"      {t('removed_ids')}: {', '.join(sorted(samples_to_remove))}")
        print(f"      {t('hint_only_data')}")



# =============================================================================
# 第十四部分：图形用户界面 / Part 14: Graphical User Interface
# =============================================================================

class ThreadSafeTextRedirector:
    """线程安全的文本重定向器 / Thread-Safe Text Redirector"""

    def __init__(self, queue_obj: queue.Queue):
        self.queue = queue_obj

    def write(self, s: str):
        if s:
            self.queue.put(s)

    def flush(self):
        pass

    def isatty(self):
        return False


class MMMApp:
    """MMM 一体化图形用户界面 / MMM Integrated GUI"""

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(t("app_title"))
        self.root.geometry("980x760")
        self.root.minsize(800, 600)

        self.font_ui = ("Microsoft YaHei", 10)
        self.font_title = ("Microsoft YaHei", 14, "bold")
        self.font_mono = ("Consolas", 10)

        # 输出队列
        self.output_queue: queue.Queue = queue.Queue()
        self.original_stdout = sys.stdout
        self.original_stderr = sys.stderr
        self.redirector = ThreadSafeTextRedirector(self.output_queue)

        self._build_ui()
        self._poll_queue()

    def _build_ui(self):
        """构建界面"""
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # 标题
        title_frame = ttk.Frame(main_frame)
        title_frame.pack(fill=tk.X, pady=(0, 10))
        self.title_label = ttk.Label(
            title_frame,
            text=t("app_title"),
            font=self.font_title,
            anchor='center'
        )
        self.title_label.pack(fill=tk.X)
        self.subtitle_label = ttk.Label(
            title_frame,
            text=t("app_subtitle"),
            font=("Microsoft YaHei", 10),
            anchor='center'
        )
        self.subtitle_label.pack(fill=tk.X)

        # 语言切换 / Language Switch
        lang_frame = ttk.Frame(main_frame)
        lang_frame.pack(fill=tk.X, pady=(0, 5))
        self.lang_label = ttk.Label(lang_frame, text=t("lang_label"), font=("Microsoft YaHei", 9))
        self.lang_label.pack(side=tk.LEFT, padx=(0, 5))
        self.lang_var = tk.StringVar(value="zh")
        lang_combo = ttk.Combobox(lang_frame, textvariable=self.lang_var, values=["zh", "en"],
                                   state="readonly", width=8)
        lang_combo.pack(side=tk.LEFT)
        lang_combo.bind("<<ComboboxSelected>>", self._on_lang_change)

        # Notebook
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True)

        # 标签页1: 矩阵构建
        self.builder_tab = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(self.builder_tab, text=t("tab_builder"))
        self._build_builder_tab()

        # 状态栏
        self.status_var = tk.StringVar(value=t("status_ready"))
        ttk.Label(
            main_frame, textvariable=self.status_var,
            font=("Microsoft YaHei", 9, "italic"), foreground="gray"
        ).pack(fill=tk.X, pady=(5, 0))

        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    # ==================== 矩阵构建标签页 ====================

    def _build_builder_tab(self):
        """构建矩阵构建标签页"""
        frame = self.builder_tab
        frame.columnconfigure(1, weight=1)

        # 输入文件
        ttk.Label(frame, text=t("label_input"), font=self.font_ui).grid(row=0, column=0, sticky=tk.W, pady=5)
        self.builder_input_var = tk.StringVar()
        ttk.Entry(frame, textvariable=self.builder_input_var, font=self.font_mono).grid(
            row=0, column=1, sticky=(tk.W, tk.E), padx=5, pady=5)
        ttk.Button(frame, text=t("btn_browse"), command=self._browse_builder_input).grid(row=0, column=2, pady=5)

        # 输出目录
        ttk.Label(frame, text=t("label_output"), font=self.font_ui).grid(row=1, column=0, sticky=tk.W, pady=5)
        self.builder_output_var = tk.StringVar()
        ttk.Entry(frame, textvariable=self.builder_output_var, font=self.font_mono).grid(
            row=1, column=1, sticky=(tk.W, tk.E), padx=5, pady=5)
        ttk.Button(frame, text=t("btn_browse"), command=self._browse_builder_output).grid(row=1, column=2, pady=5)

        # 标记类型
        ttk.Label(frame, text=t("label_marker"), font=self.font_ui).grid(row=2, column=0, sticky=tk.W, pady=5)
        self.marker_var = tk.StringVar(value=t("auto_detect"))
        self.marker_combo = ttk.Combobox(frame, textvariable=self.marker_var, values=[t("auto_detect"), "SSR", "SNP"],
                     state="readonly", width=15)
        self.marker_combo.grid(row=2, column=1, sticky=tk.W, padx=5, pady=5)

        # 高级选项
        self.options_frame = ttk.LabelFrame(frame, text=t("frame_options"), padding="10")
        self.options_frame.grid(row=3, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=10)

        self.threads_var = tk.BooleanVar(value=True)
        self.threads_chk = ttk.Checkbutton(self.options_frame, text=t("chk_threads"), variable=self.threads_var)
        self.threads_chk.grid(row=0, column=0, sticky=tk.W, padx=5)

        # 按钮
        btn_frame = ttk.Frame(frame)
        btn_frame.grid(row=4, column=0, columnspan=3, pady=10)

        self.run_builder_btn = ttk.Button(btn_frame, text=t("btn_run"), command=self._start_builder, width=18)
        self.run_builder_btn.pack(side=tk.LEFT, padx=5)

        # 使用说明
        self.help_frame = ttk.LabelFrame(frame, text=t("frame_help"), padding="5")
        self.help_frame.grid(row=5, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=5)
        self.help_label = ttk.Label(self.help_frame, text=t("help_text"), font=("Microsoft YaHei", 8), foreground="gray")
        self.help_label.pack(anchor=tk.W)

        # 日志
        self.log_frame = ttk.LabelFrame(frame, text=t("frame_log"), padding="5")
        self.log_frame.grid(row=6, column=0, columnspan=3, sticky=(tk.W, tk.E, tk.N, tk.S), pady=5)
        self.log_frame.columnconfigure(0, weight=1)
        self.log_frame.rowconfigure(0, weight=1)
        frame.rowconfigure(6, weight=1)

        self.builder_log = scrolledtext.ScrolledText(self.log_frame, wrap=tk.WORD, font=self.font_mono,
                                                      state=tk.DISABLED, height=18)
        self.builder_log.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

    def _on_lang_change(self, event=None):
        """语言切换事件 / Language switch event"""
        I18n.set_lang(self.lang_var.get())
        self._refresh_ui_text()

    def _refresh_ui_text(self):
        """根据当前语言刷新所有界面文本 / Refresh all UI text based on current language"""
        self.root.title(t("app_title"))
        # Refresh title labels
        self.title_label.config(text=t("app_title"))
        self.subtitle_label.config(text=t("app_subtitle"))
        # Refresh lang label
        self.lang_label.config(text=t("lang_label"))
        # Refresh tab text
        self.notebook.tab(self.builder_tab, text=t("tab_builder"))
        # Refresh status bar
        self.status_var.set(t("status_ready"))
        # Refresh run button
        self.run_builder_btn.config(text=t("btn_run"))
        # Refresh marker combo values and current text
        current_marker = self.marker_var.get()
        if current_marker in ("自动检测", "Auto Detect"):
            self.marker_var.set(t("auto_detect"))
        self.marker_combo.config(values=[t("auto_detect"), "SSR", "SNP"])
        # Refresh help text
        self.help_label.config(text=t("help_text"))
        # Refresh LabelFrames directly
        self.options_frame.config(text=t("frame_options"))
        self.help_frame.config(text=t("frame_help"))
        self.log_frame.config(text=t("frame_log"))
        # Refresh checkbutton directly
        self.threads_chk.config(text=t("chk_threads"))
        # Refresh labels and browse buttons in builder_tab
        for widget in self.builder_tab.winfo_children():
            if isinstance(widget, ttk.Label):
                text = widget.cget("text")
                if "CSV" in text or "csv" in text or "输入" in text:
                    widget.config(text=t("label_input"))
                elif "输出" in text or "Output" in text or "目录" in text:
                    widget.config(text=t("label_output"))
                elif "标记" in text or "Marker" in text:
                    widget.config(text=t("label_marker"))
            elif isinstance(widget, ttk.Button):
                btn_text = widget.cget("text")
                if "浏览" in btn_text or "Browse" in btn_text:
                    widget.config(text=t("btn_browse"))
            elif isinstance(widget, ttk.Frame):
                for child in widget.winfo_children():
                    if isinstance(child, ttk.Button):
                        btn_text = child.cget("text")
                        if "浏览" in btn_text or "Browse" in btn_text:
                            child.config(text=t("btn_browse"))

    def _browse_builder_input(self):
        filename = filedialog.askopenfilename(title=t("dialog_select_input"),
                                               filetypes=[(t("filetype_csv"), "*.csv"), (t("filetype_all"), "*.*")])
        if filename:
            self.builder_input_var.set(filename)
            if not self.builder_output_var.get():
                default_out = os.path.join(os.path.dirname(filename), "MMM_Output")
                self.builder_output_var.set(default_out)

    def _browse_builder_output(self):
        dirname = filedialog.askdirectory(title=t("dialog_select_output"))
        if dirname:
            self.builder_output_var.set(dirname)

    def _start_builder(self):
        input_file = self.builder_input_var.get().strip()
        output_dir = self.builder_output_var.get().strip()

        if not input_file or not os.path.isfile(input_file):
            messagebox.showerror(t("error"), t("err_no_input"))
            return
        if not output_dir:
            messagebox.showerror(t("error"), t("err_no_output"))
            return
        # Ensure output directory exists and is writable (create if necessary)
        try:
            output_dir = os.path.abspath(output_dir)
            os.makedirs(output_dir, exist_ok=True)
        except Exception as e:
            messagebox.showerror(t("error"), f"Cannot create output directory:\n{str(e)}")
            return
        # final writability check
        if not os.access(output_dir, os.W_OK):
            messagebox.showerror(t("error"), f"Cannot write to output directory:\n{output_dir}")
            return

        self.run_builder_btn.configure(state=tk.DISABLED)
        self.status_var.set(t("status_building"))
        self.builder_log.configure(state=tk.NORMAL)
        self.builder_log.delete(1.0, tk.END)
        self.builder_log.configure(state=tk.DISABLED)

        sys.stdout = self.redirector
        sys.stderr = self.redirector

        marker_type = self.marker_var.get()
        if marker_type == t("auto_detect"):
            marker_type = None

        config = MMMConfig(
            input_file=input_file,
            output_dir=output_dir,
            marker_type=marker_type,
            use_multithreading=self.threads_var.get()
        )

        thread = threading.Thread(target=self._run_builder_thread, args=(config,), daemon=True)
        thread.start()

    def _run_builder_thread(self, config: MMMConfig):
        try:
            workflow = MMMWorkflow(config)
            results = workflow.run()
            self.root.after(0, self._on_builder_success, results)
        except Exception as e:
            self.root.after(0, lambda err=e: self._on_builder_error(err))
        finally:
            sys.stdout = self.original_stdout
            sys.stderr = self.original_stderr
            self.root.after(0, self._reset_builder_ui)

    def _on_builder_success(self, results: MMMResults):
        msg = t("msg_success")
        if results.grading_result:
            msg += f"\n\n{t('grading_success_title')}\n  MGI: {results.grading_result['MGI']:.4f}\n  {t('dup_groups')}: {len(results.grading_result['duplicate_groups'])}"

        messagebox.showinfo(t("msg_success"), msg)

    def _on_builder_error(self, error: Exception):
        messagebox.showerror(t("error"), f"❌ {t('error')}: \n\n{str(error)}")

    def _reset_builder_ui(self):
        self.run_builder_btn.configure(state=tk.NORMAL)
        self.status_var.set(t("status_ready"))

    # ==================== 通用方法 ====================

    def _poll_queue(self):
        """在主线程中轮询输出队列并更新日志"""
        try:
            while True:
                text = self.output_queue.get_nowait()
                log_widget = self.builder_log
                log_widget.configure(state=tk.NORMAL)
                log_widget.insert(tk.END, text)
                log_widget.see(tk.END)
                log_widget.configure(state=tk.DISABLED)
        except queue.Empty:
            pass
        self.root.after(100, self._poll_queue)

    def _on_close(self):
        self.root.destroy()


# =============================================================================
# 第十五部分：命令行接口与程序入口 / Part 15: CLI & Entry Point
# =============================================================================

def create_parser() -> argparse.ArgumentParser:
    """创建命令行参数解析器"""
    parser = argparse.ArgumentParser(
        description='孟德尔错配矩阵分析系统 - v1.0',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 启动图形界面（无参数时自动启动）
  python MMMAS.py

  # 从原始基因型构建矩阵
  python MMMAS.py -i input.csv -o output_dir

  # 指定SSR标记
  python MMMAS.py -i input.csv -o output_dir -m SSR

  # 大规模数据（>1000样本）
  python MMMAS.py -i large_dataset.csv -o ./large_results/ -cs 500

  # 英文界面
  python MMMAS.py -i data.csv -o ./results/ -l en
        """
    )

    parser.add_argument('-i', '--input', help='输入原始基因型CSV文件路径')
    parser.add_argument('-o', '--output', default='./MMM_Output/',
                        help='输出目录路径（默认：./MMM_Output/）')
    parser.add_argument('-m', '--marker-type', choices=['SSR', 'SNP'],
                        help='标记类型（SSR/SNP，默认自动检测）')
    parser.add_argument('-ng', '--no-grading', action='store_true',
                        help='关闭自动分级')
    parser.add_argument('-nc', '--no-checkpoint', action='store_true',
                        help='关闭检查点')
    parser.add_argument('-nm', '--no-multithreading', action='store_true',
                        help='关闭多线程')
    parser.add_argument('-cs', '--chunk-size', type=int, default=1000,
                        help='分块大小（默认：1000）')
    parser.add_argument('-l', '--language', choices=['zh', 'en'], default='zh',
                        help='界面语言（zh/en，默认：zh）')
    parser.add_argument('-v', '--version', action='version', version=f'%(prog)s {__version__}')

    return parser


def main():
    """主入口函数"""
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8")

    # 无命令行参数时自动启动GUI
    if len(sys.argv) <= 1:
        root = tk.Tk()
        MMMApp(root)
        root.mainloop()
        return 0

    parser = create_parser()
    args = parser.parse_args()

    # 设置界面语言
    I18n.set_lang(args.language)

    # GUI模式
    if not args.input:
        root = tk.Tk()
        MMMApp(root)
        root.mainloop()
        return 0

    # 矩阵构建模式
    if not args.input:
        parser.print_help()
        print(f"\n{t('error')}: --input is required for matrix build mode")
        return 2

    config = MMMConfig(
        input_file=args.input,
        output_dir=args.output,
        marker_type=args.marker_type,
        use_multithreading=not args.no_multithreading,
        enable_checkpoint=not args.no_checkpoint,
        auto_grading=not args.no_grading,
        chunk_size=args.chunk_size
    )

    try:
        workflow = MMMWorkflow(config)
        results = workflow.run()

        if results.validation_report.get("compliant", False):
            return 0
        else:
            print("\n⚠ Warning: Matrix did not pass all mathematical validations")
            return 1

    except Exception as e:
        print(f"\n✗ {t('error')}: {str(e)}")
        import traceback
        traceback.print_exc()
        return 2


if __name__ == "__main__":
    sys.exit(main())
